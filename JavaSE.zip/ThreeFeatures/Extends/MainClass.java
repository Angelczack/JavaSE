package Ataraxia.JavaSE.ThreeFeatures.Extends;

public class MainClass {
    public static void main(String[] args){
        Subclass subclass = new Subclass();
        subclass.inheritance();
    }
}
