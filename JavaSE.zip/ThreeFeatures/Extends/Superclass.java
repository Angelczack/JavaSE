package Ataraxia.JavaSE.ThreeFeatures.Extends;

public class Superclass {//父类、超类、基类
    //分别定义四个不同修饰符的成员属性
    private int age=18;
    //除了私有化修饰符不可以直接访问，其他均可，所以需要封装后在访问
    public String name="java";
    protected int salary=3000;
    int cellphone=135987541;
    public int getAge(){
        return age;
    }
    public Superclass(){
        System.out.println("我是父类构造器");
    }
    public Superclass(String name,int salary){
        this();//调用无参本类构造器，但不能与super同用
        System.out.println("父类第二个构造器的名字："+name+"\t薪水："+salary);
    }

    void address(){
        System.out.println("-----我是父类类address------");
    }
}
