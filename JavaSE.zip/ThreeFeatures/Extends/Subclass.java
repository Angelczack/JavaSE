package Ataraxia.JavaSE.ThreeFeatures.Extends;

public class Subclass extends Superclass{//子类、派生类

    public void inheritance() {
        System.out.println("年龄:"+getAge());
        //this. =默认，若子父类有相同的address，是优先查找本类中的address，若没有找父类
        //super 关键字是直接查找父类，二者都是在构造器第一行,这里无需留一个
        this.address();
        super.address();
        address();//方法重写，若两个方法名，返回类型，参数都为一样，则子类覆盖父类，除非用关键字引用，且只用于方法
    }
    void address(){
        System.out.println("-----我是子类address-----");
    }
    public Subclass(){//当创建一个子类的无参构造器时，将自动调用继承的无参父类构造器
        //默认关键字为：super(); 且位于子类类体上方
        //但当父类有多个重载构造器时，指定super进行调用
        super("java",200);//必须处在第一行，this关键字也是同样，所以二者在构造器只能存在一个
        System.out.println("我是子类构造器");

        System.out.println(cellphone+salary);
        //继承调用无需创建对象

        System.out.println(super.cellphone+super.salary+super.name);
        //同样super可以直接调用父类除private之外的所有属性和方法，并且不需要创建对象
    }
}
