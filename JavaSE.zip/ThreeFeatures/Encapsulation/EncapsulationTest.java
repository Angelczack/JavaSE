package Ataraxia.JavaSE.ThreeFeatures.Encapsulation;

public class EncapsulationTest {
/*不能随便查看人的年龄,工资等隐私,并对设置的年龄进行合理的验证。
年龄合理就设置,否则给默认年龄,必须在1-120,年龄,工资不能直接查看，
name的长度在2-6字符之间
 */
    public static void main(String... args){
        encap parameter = new encap();//两个构造器初始化需要给原先的默认一个构造器
        parameter.setName("Jackcccccc");
        parameter.setAge(0);
        parameter.setSalary(3000);
        //调用修改好的修改语句

        String getSentence = "name="+parameter.getName()
                +"\nage="+parameter.getAge()
                +"\nsalary="+parameter.getSalary();
        //调用读取语句
        System.out.println(getSentence);

        encap en = new encap("smith",200,5000);
        System.out.println("=======smith=======");
        System.out.println(en.info());
    }
}
class encap{
    public String name;
    private int age;
    private int salary;

    public encap(String name,int age,int salary){
        //若是定义一个构造器传参
        //防护机制没有意义，所以不能绕过构造器
//        this.name = name;
//        this.age = age;
//        this.salary = salary;
        //所以可以在这里面调用封装方法
        this.setName(name);
        this.setAge(age);
        this.setSalary(salary);

    }
    public String info(){
        return "name="+name
                +"\nage="+age
                +"\nsalary="+salary;
    }
    public encap(){}//默认一个无参构造器进行初始化
    public void setName(String name){//set+变量名首字母大写为修改,set方法可接收形参
        if(2<=name.length() && name.length()<=6)
        this.name = name;
        else System.out.println("名字错误");
    }
    public String getName(){//get+变量名首字母大写为读取
        return name;
    }
    public void setAge(int age){
        if(age>=1 && age<=120)
        this.age = age;
        else {System.out.println("年龄有误，给予默认值20");
            this.age=20;
        }
    }
    public int getAge(){
        return age;
    }
    public void setSalary(int salary){
        if(salary<-1)
        this.salary = salary;
        else System.out.println("无法查看哦，给你一个底薪啦");
        this.salary =3000* (int)(Math.random()+1);
    }
    public int getSalary(){
        return salary;
    }
}

