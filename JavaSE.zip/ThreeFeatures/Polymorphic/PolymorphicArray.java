package Ataraxia.JavaSE.ThreeFeatures.Polymorphic;

public class PolymorphicArray {
    /*应用实例:现有一个继承结构如下:要求创建1个Person对象、2个Student对象和2个Teacher对象
    统一放在数组中,并调用每个对象say方法.
    如何调用子类特有的方法，比如Teacher有一个teach , Student有一个study怎么调用?
     */

    public static void main(String... args){
        //多态数组
        Person[] persons = new Person[5];
        persons[0] = new Person("火星人",500);
        //Person persons = new Student();
        //向上转型:编译:persons.say(),运行的是student.say();
        //此转型只能调用父类的方法，如果子类没有相同则显示父类原方法
        //属性没有重写，所以向上转型的值是编译阶段的

        //向下转型:Student st = (Student) person(); 这里是父类的引用
        //向下转前要用向上转型引出父类的引用，此转型可调用子类所有方法
        persons[1] = new Student("李同学",18,65);
        persons[2] = new Student("王班长",19,99);
        persons[3] = new Teacher("唐老师",25,5154.5);
        persons[4] = new Teacher("杨主任",45,20000.12);
        for(int i=0;i<persons.length;i++) {
            System.out.println(persons[i].say());
            //动态绑定机制：当向上转型的子类没有重写的方法后会调用父类的方法，
            //当父类方法中又返回方法(此方法又是子类的)则回去调该需要调用的方法

            //同上，对属性不影响，又返回属性值，以就近原则调用
            if (persons[i] instanceof Student) {
                //instanceof:左侧的对象是右侧类的实例或者是右侧类子类的实例
                //左边是对象，右边是类，二者为继承关系
                ((Student) persons[i]).student();//向下转型
            }else if(persons[i] instanceof Teacher){
                ((Teacher)persons[i]).teacher();//向下转型
            }else if(persons[i] instanceof Person){
                //只有student和teacher设立了独立方法，person时不执行任何
            }else{
                System.out.println("抱歉，有误");
            }
        }
    }
}
class Person{
    private String name;
    private int age;
    public Person(String name,int age){
        this.name = name;
        this.age = age;
    }
    //以下所有封装均可不写，因为没用到
    public String getName(){return name;}
    public void setName(String name){this.name = name;}
    public int getAge(){return age;}
    public void setAge(int age){this.age = age;}
    //
    String say(){//say方法
        return "name is :"+name+"\tage is:\t"+age;
    }
}
class Student extends Person{
    private int score;
    //
    public int getScore(){return score;}
    public void setScore(){this.score = score;}
    //
    public Student(String name,int age,int score){//构造器
        super(name,age);
        this.score = score;
    }
    public String say(){//重写方法
        return super.say()+"\tscore is:"+score;
    }
    public void student(){
        System.out.println("学生"+getName()+"正在学习...");
    }
}
class Teacher extends Person{
    private double salary;
    //
    public double getSalary(){return salary;}
    public void setSalary(double salary){this.salary = salary;}
    //
    public Teacher(String name,int age,double salary){
        super(name,age);
        this.salary = salary;
    }
    public String say(){
        return super.say()+"\tsalary is:"+salary;
    }
    public void teacher(){
        System.out.println("老师"+getName()+"正在教学...");
    }
}
