package Ataraxia.JavaSE.CodeBlock;

public class CodeBlock {
    //无继承情况：static 代码块优先于普通代码块和构造器,若有多个static或普通代码块会从上而下按顺序执行
    /*继承情况：由于静态代码块是由类加载而运行，并只能运行一次。普通代码块(构造)由对象的创建而调用，并且一个继承类中除了隐藏的super()以外还有空普通代码块
        所以一个类继承另一个类时，会先加载父类(静态代码块，多个时按顺序),在加载子类(···)，而后继续加载父类的普通代码块与构造器，最后是子类的普通代码块和构造器(各由上至下)
        当然各个类的优先级还是普通代码块大于构造器
        */
    /*!!方法体之内:{}为普通代码块   类中{}为构造代码块  上面说过,区分一下
        类中优先级:静态>构造>构造器
        方法中:构造>构造器
        在类中创建本类static对象:  加载构造器前会执行构造代码块,最后有静态再执行
     */
    public static void main(String[] args) {
        block block = new block();
    }

    static{
        System.out.println("父类静态代码块");
    }
    public CodeBlock(){
        System.out.println("父类无参构造器");
        }
    {
        System.out.println("父类普通代码块");
    }
}
class block extends CodeBlock{
    static {
        System.out.println("子类静态代码块");
    }
    {
        System.out.println("子类普通代码块");
    }
    public block(){
        System.out.println("子类无参构造器");
    }

}
