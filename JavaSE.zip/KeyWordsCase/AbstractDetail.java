package Ataraxia.JavaSE.KeyWordsCase;

public class AbstractDetail {
    //抽象类有普通类所有的所有东西，只是多了一个抽象方法，此方法只能声明； 继承关系必须同样是abstract类或者重写父类抽象方法
    //抽象方法不能定义为private、static、final，因为这些关键字与重写所违背
    //继承者必须重写抽象类的所有抽象方法,但可以不需要重写未被定义抽象的方法
}
abstract class Place{
    public abstract void Beijing();//声明抽象方法，不能私有化
    void Nanjing(){}
}
/*abstract*/ class Builds extends Place{
    public void Beijing(){
        System.out.println("抽象方法与抽象类");
    }
    @Override
    void Nanjing(){}
}
