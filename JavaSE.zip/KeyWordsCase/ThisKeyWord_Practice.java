package Ataraxia.JavaSE.KeyWordsCase;
import java.util.Scanner;

public class ThisKeyWord_Practice {
    /*定义Person类，里面有name、age属性
    /并提供compareTo比较方法,用于判断是否和另一个人相等
    提供测试类TestPerson用于测试，名字和年龄完全一样,就返回true,否则返回false
     */
    public static void main(String... args){
        Scanner sc = new Scanner(System.in);
        Person p1 = new Person("张三",30);
        Person p2 = new Person("李四",20);
        //两个都分开执行了一遍
        System.out.println(p1.compareTo(p2));
        //但是p1.compareTo(p2)指p1的方法中p2的值传递
        //构造器对对象赋值了张三与30，p1为引用
        another an = new another();

    }
}
class Person{
    String name;
    int age;
    public Person(String name,int age){//构造器:与类名相同，并且没有返回值与void
        this.name=name;
        this.age=age;
        System.out.println(name+age);
    }
    boolean compareTo(Person p){
        System.out.println(this.name);
        //当前类属性为p1引用的张三与30和p调用p2的李四与20
        return (this.name.equals(p.name))&&(this.age==p.age)?true:false;
    }
}

class another{
    public another(){//关于构造器this使用：只能在构造器访问另一个构造器  this();
    this("构造器",200);//并且此语句必须在第一条
    }
    public another(String name,int price){
         System.out.println("另一个构造器所引用的构造器:"+name+"\t"+price);
    }
}

