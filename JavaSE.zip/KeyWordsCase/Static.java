package Ataraxia.JavaSE.KeyWordsCase;

public class Static {
    public static void main(String[] args) {
        new Case().people("king",18);
        //普通方法需创建对象调用
        //而静态方法不仅可以对象调用，也可以通过类名直接访问
        Case.tool();
        System.out.println("========");
        //！并且通过多次访问的静态变量值可以叠加，实例变量只能一次访问相同值
        new Case().count();//9
        new Case().count();//叠加为10
        System.out.println(Case.count);
        //这个访问的不是方法,而是类变量count，先访问后++，count为11
    }
}
class Case{
    public String name;
    public static int age;
    public static int length;
    static int count = 9;//用来证明static访问值可以叠加
    //工具人,其他关键字
    public static void tool(){
        //this.name;   在静态方法下，其他关键字(this/super)无法使用
        //静态方法只能用静态的东西，它是个工具人
        //people();  /  name
        length = 100;
        System.out.println("该工具长度为："+length);
    }
    public void people(String name,int age){
        //非静态变量/方法可以访问静态变量/方法
        tool();
        System.out.println("========");
        //正常方式引用
        this.name = name;
        this.age = age;
        System.out.println("我叫"+name+"\t年龄是:"+age);


    }
    void count(){
        System.out.println("count:"+(count++));//先访问后累加
    }
}
