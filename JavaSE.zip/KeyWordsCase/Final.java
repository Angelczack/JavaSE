package Ataraxia.JavaSE.KeyWordsCase;

public class Final {
    public static void main(String[] args) {
        //final 所修饰的变量最好用大写
        //final 所修饰的任何(包括方法、属性、重写)都无法做出改变,但是继承中，虽然方法无法覆盖，但是方法可以被继承(若final修饰为类，则无效);
        //  但只是定义未赋值，可在构造器或者代码块中赋值.

        /* 且只能赋值一次，静态属性只能在代码块中赋值(无法在构造器),实例变量也只能在普通代码块和构造器中赋值
            因为，static final使类不会加载，只会单独调用本属性，但若本属性没有赋值就会自动向下寻找赋值语句并运行此static类型，其他的static不会运行；若赋值了则不继续运行

         */
        System.out.println(new Animal().NAME);//普通属性按优先级顺序执行

        System.out.println(BBB.num);
        //注：若是final修饰的类则方法可以不用写，final与static共用可以使效率更高(类不会加载)
    }
}
class Animal{
    final String NAME;
    static final int AGE;//当类加载时，会调用static属性和方法，若是在构造器中则无法进入
    /*{
        NAME = "老虎";
    }*/
    Animal(){
        this.NAME = "动物";
    }
    static {
        AGE = 12;
        System.out.println(AGE);
    }
    final void tiger(){
        System.out.println("老虎");
    }
}
class mince extends Animal{
    //void tiger(){}


}
class BBB{
    static final double num = 2.2;
    //当类执行时，应该按顺序调用所有的static属性，但final同时修饰时，类不会加载，也就只有专门调用的属性会执行
    //若在static代码块里赋值还是会被运行
    static {

        System.out.println("mince被执行");
    }
}
