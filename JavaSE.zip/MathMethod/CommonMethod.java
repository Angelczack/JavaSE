package Ataraxia.JavaSE.MathMethod;

public class CommonMethod {
    //除了经常用的Math方法:sqrt()、random()、abs()、max()、min();以外添加几个常用方法
    public static void main(String[] args) {
        //1.pow 求幂
        double n1 = Math.pow(2,4);
        System.out.println("2的4次方:"+n1);
        //2.ceil 向上取整:>=ceil的最小整数
        double n2 = Math.ceil(5.03);
        System.out.println(">=5.03的最小整数:"+n2);
        //3.floor 向下取整:<=floor的最大整数
        double n3 = Math.floor(4.89);
        System.out.println("<=4.89的最大整数:"+n3);
        //4.round 四舍五入
        long n4 = Math.round(8.89);
        System.out.println("8.89四舍五入后:"+n4);
    }
}
