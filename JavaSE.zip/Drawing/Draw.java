package Ataraxia.JavaSE.Drawing;

import javax.swing.*;
import java.awt.*;

public class Draw extends JFrame{//继承java的画框
    private MyPanel mp = null;//首先初始化一个面板
    public static void main(String[] args) {//java绘图技术
        new Draw();
    }
    public Draw(){//main是静态的,创造一个构造器实现
        mp = new MyPanel();//创建一个面板
        this.add(mp);//在画框里添加一个画板
        this.setSize(600,600);//修改画框的大小
        this.setVisible(true);//将画框可视化
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//当点击窗口小×时退出程序
    }
}
/*画板中paint方法没有被调用,为什么能被执行  的原因
    1.第一次在屏幕显示时,程序会自动调用paint()方法来绘制组件
    2.窗口最小化，然后最大化  会被再次调用
    3.窗口的大小发生变化     会被再次调用
    4.repaint函数被调用
 */
class MyPanel extends JPanel {//继承java的画板
    //重写paint画图方法
    @Override
    public void paint(Graphics g){//可以把g理解为一只笔
        super.paint(g);//不能省略,省略了则自动调用父类的无参paint
        g.drawOval(10,10,300,200);//椭圆形
        g.drawRect(20,20,200,200);//矩形    Line:直线
        //调用椭圆形方法,画出一个椭圆形10,10为x,y个像素单位的坐标(不是圆心,交点是左上角),后两个是长和高

        //插入图片:图片放置out下面的folder根目录
        Image image = Toolkit.getDefaultToolkit().getImage(Draw.class.getResource("/1.png"));
        g.drawImage(image,100,100,463,82,this);
        //设置字体
        g.setColor(Color.red);
        g.setFont(new Font("行楷",Font.BOLD,20));//用对象
        g.drawString("我",300,300);//这个比较特殊，其交点在左下角
    }
}