package Ataraxia.JavaSE.RecursionCase;

public class Recursion_The_Mouse_Flee {
    public static void main(String[] args){
        /*The notion:
            First,We should establish two dimensional array:rows-eight and cols-seven
            and these outside get obstacle
            ===============================
            And then,accomplish establishing , we will render the mouse to set 2,
            if the mouse go through and want to return,it means that the way have been gone,
            render this way to set three;
        */

        int arr[][] = new int[8][7];
        int rows,cols;
        recursion(arr);
        Recursion2 temp = new Recursion2();
        //transmit the mouse site of start
        temp.MouseFlee(arr,1,1);
        System.out.println("======After the mouse get away=======");
        array(arr);
    }
        static void array(int arr[][]){
            int rows,cols;
            //export;
            for(rows=0;rows<arr.length;rows++){
                for(cols=0;cols<arr[rows].length;cols++)
                    System.out.print(arr[rows][cols]+"  ");
                System.out.println();
            }
        }
       static void recursion(int arr[][]){
            int rows,cols;
           //初始化数组
           //Make outside of way(0) to become 1
           for(rows=0;rows<arr[rows].length;rows++){
               arr[0][rows]=1;
               arr[7][rows]=1;
           }
           for(cols=0;cols<arr.length;cols++){
               arr[cols][0]=1;
               arr[cols][6]=1;
           }
           //The two point is also barrier;
           arr[3][1]=1;
           arr[3][2]=1;
           array(arr);

    }
}

class Recursion2{
    public boolean MouseFlee(int arr[][],int rows,int cols){
        if(arr[6][5]==2)return true;
        //when rows ==6 and cols==6,the mouse get away triumph
        else {
            //If the mouse can pass,should turn 2 and go on ,otherwise return false;
            if (arr[rows][cols] == 0) {
                arr[rows][cols] = 2;

                //The direction adhere sequence:左(left) 下(descend) 右(right) 上(right)
                //And this is continual , so we have to use recursion

                if (MouseFlee(arr, rows, cols-1)) //left
                    return true;
                 else if (MouseFlee(arr, rows+1, cols)) //descend
                    return true;
                 else if (MouseFlee(arr, rows, cols+1)) //right
                    return true;
                 else if (MouseFlee(arr, rows-1, cols)) //rise
                    return true;
                 else {
                    //if the way have not route , which illustrate the route haven been gone through
                    arr[rows][cols] = 3;
                    return false;
                }
            } else
                //met 1,2,3
                return false;

        }
    }
}

