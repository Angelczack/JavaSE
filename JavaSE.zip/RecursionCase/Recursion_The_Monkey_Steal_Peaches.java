package Ataraxia.JavaSE.RecursionCase;
/*猴子吃桃子问题:有一堆桃子，猴子第一天吃了其中的一半，并再多吃了一个!
以后每天猴子都吃其中的一半，然后再多吃一个。
当到第10天时，想再吃时(即还没吃)发现只有1个桃子了。问题:最初共多少个桃子?
*/
class Recursion_The_Monkey_Steal_Peaches {
    public static void main(String[] args){
        Peach p = new Peach();
        int a=p.test(1);
        System.out.println(a);
    }
}
class Peach {
    int test(int day) {
        //day10 1
        //day9=(day10+1)*2;
        //day8=(day9+1)*2;
        //day7=(day8+1)*2;
        if (day == 10) {
            return 1;
        } else if (1 <= day && day <= 9) {
            return (test(day + 1) + 1) * 2;
        } else {
            System.out.println("error,The day isn't exist");
            return 0;
        }
    }
}

