package Ataraxia.JavaSE.RecursionCase;

public class Recursion_HanoiTower {
    public static void main(String[] args){
       //The game is that put 'A' 's round plate to move 'C'
        Move mv = new Move();
        //receive number of round plate ,'A' column , 'B' column and 'C' column
        mv.move(5,'A','B','C');
    }
}

class Move{
    void move(int num,char A,char B,char C){
        //First,we can suppose that the 'A' only has one round plate
        if(num==1){
            System.out.println(A+"->"+C);
        }else{//The number not only one
            move(num-1,A,C,B);
            //if num =5,We can look at the top four of 'A' column as a whole
            //and the 'C' column help 'A' column moved 'B' column
            System.out.println(A+"->"+C);
            //moved,put final round plate to move 'C'

            move(num-1,B,A,C);
            //likewise,the 'A' column help 'B' column moved 'C' column
        }
    }
}
