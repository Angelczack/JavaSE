package Ataraxia.JavaSE.Interface;

public class Lambda {//lambda表达式:任何接口，若只包含唯一一个抽象方法，那么它就是函数式接口
    //可以通过lambda表达式来创建该接口对象
    public static void main(String[] args) {
        //先使用匿名内部类  无名,只有匿名内部类可以创建化接口实例
        Car car = new Car(){//接口/实现接口的类都可
            public void reverse(){
                System.out.println("内部类实现倒车");
            }
        };
        car.reverse();

        //lambda 语法 :  实现接口 = 参数列表()->{语句};  若参数只有一个,可省小括号;若方法体只有一行语句,可省大括号,若有返回值也可省
        /*关于方法和类
            1.对象::方法名   2.类::静态方法名  3.实例方法的调用者::方法的传入参数  例.比较字符串 : pp2 = String :: equals
            4.构造方法  类名::new   注:有无参根据接口的泛型定义

            //例如：list集合转换为整数数组  int[] ints = list.stream().mapToInt(x -> x).toArray();
                原式:  int[] ints = list.stream().mapToInt(stream = (x)->{return Integer.intValue(x)}.toArray)

                解：将list转换成流形式在mapToInt中转成int类型,最后转为数组
         */
        car = ()->{
            System.out.println("lambda实现倒车");
        };
        car.reverse();
    }
}
interface Car{
    void reverse();
}
