package Ataraxia.JavaSE.Interface;

public class Main {
    public static void main(String[] args) {
        //接口的作用：多个类执行一个接口时，可以反复调用同样的方法名;如果是按类继承一个类就有多个不同的方法名调用，代码重用率低

        //USB usb = new USB();  接口无法实例化
        phone phone = new phone();
        computer.work(phone);
        mouse mouse = new mouse();
        computer.desk(mouse,mouse);
        System.out.println(USB.i);//证明i为静态
        //USB.i = 12;  证明i为final
    }
}
//接口与类相同，修饰符只能是public和默认
interface rate extends DPI,USB{//(只有)接口与接口之间可以互相继承,并且可以多个

}

interface DPI{
    public void move();
    default void nn() {
        System.out.println("除了声明，default和static可以修饰默认方法实现");
    }
}

interface USB{//接口中的所有方法和属性默认public，抽象方法默认有abstract，可以省略不写
    int i = 10;//接口中的属性默认为：public static final int i =10;
    void start();
    void stop();
}
class phone implements USB{//一个普通类必须实现接口类的所有抽象方法
    public void start(){
        System.out.println("phone开始执行");
    }
    public void stop(){
        System.out.println("phone停止执行");
    }
}

class mouse implements USB,DPI{//一个类可以实现多个接口
    public void start(){
        System.out.println("鼠标开始点击");
    }
    public void stop(){
        System.out.println("鼠标停止点击");
    }
    public void move(){
        System.out.println("鼠标正在移动");
    }
}

abstract class tel implements USB{}//抽象类可以不用实现接口类的抽象方法

class computer{
    public static void work(USB usb){
        usb.start();
        usb.stop();
    }
    static void desk(USB usb,DPI dpi){
        usb.start();
        usb.stop();
        dpi.move();
    }
}

