package Ataraxia.JavaSE.Map;

import java.util.*;

//HashTable 用法与HashMap一样,但不同的是:它是安全的(与Vector和ArrayList的关系一样);它的k-v不能是null,否则会空指针异常
//其子类:properties类与HashTable用法一样,区别在于IO流操作中和读取文件操作

public class Map_ {//双列集合
    /*Map与Collection是并列存在,map.put(key,value);     =list.add();
       其中,跟Set接口相同,key不可以重复,value可以重复;若重复的key,最新的会覆盖相同的(Set中是后续不可重复)
       并且,key和value是一对一关系,通过key可以找到value
       由于,HashSet底层是HashMap,所以有很多类似,例如取出的元素无序
    */
    public static void main(String[] args) {
        Map map = new HashMap();
        map.put("n1","java");
        map.put("n3","python");
        map.put("n2","java");
        map.put("n5","java");
        map.put("n5","c++");
        map.put(null,null);//HashMap的k-v都可以为null
        System.out.println(map);
        System.out.println("n5对应的值:"+map.get("n5"));
        create(map);
        CommonMethod();
    }
    static void create(Map map){
        //遍历:创建Map对象
        //调用entrySet集合:entrySet是HashMap中的一个集合,
        // entrySet中又有Entry类型
        Set set = map.entrySet();
        for(Object obj : set){
            //解读:一个HashMap数组链表中,有entrySet的集合,存入的每一个数据的类型都是一个Entry,
            //其中k-v的内容就是属于HashMap$Node
            Map.Entry entry = (Map.Entry)obj;//向下转型
            System.out.println(entry.getKey()+"-"+entry.getValue());
        }
        System.out.println("=================");
        //接下来是其他遍历方式:!!加上上面一共三种方式,每一种方式有迭代器和增强循环两种方法
        //只展示一部分的迭代器和for
        // 1.通过keySet获取所有的键,然后再通过键获取value
        // 2.通过values值获取所有的值
        System.out.println("=====for第一种=========");
        Set keys = map.keySet();//keySet与entrySet一样，属于Set
        for(Object obj1 : keys){
            System.out.println(obj1+"-"+map.get(obj1));
        }
        System.out.println("=========iterator第一种======");
        Iterator it1 = keys.iterator();
        while(it1.hasNext()){
            Object obj2 = it1.next();
            System.out.println(obj2+"-"+map.get(obj2));
        }

        System.out.println("============for第二种");
        Collection col = map.values();//values是属于集合,这里可以使用Collection所有的遍历方法
        for(Object value : col){
            System.out.println(value);//只能取出所有的value值
        }
        System.out.println("=================");
    }
    static void CommonMethod(){
        //常用方法
        /*1.put(k-v);
        2.remove(k)/(k-v);
        3.get(k);
        4.size();  获取元素个数
        5.isEmpty();  判断是否为空
        6.clear();
        7.containsKey(k);  查看键是否存在
         */
    }
}
