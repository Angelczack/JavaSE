package Ataraxia.JavaSE.Reflection.Reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class AboutConstructor {
    public static void main(String[] args) throws Exception{
        //利用反射机制获取类的实例(以通过构造器为主)
        //无参
        Class cls1 = Class.forName("Ataraxia.JavaSE.Reflection.Reflect.Each");
        Object o1 = cls1.newInstance();
        System.out.println("无参"+o1);
        //公共有参 先通过构造器创建,再获取实例  注：getConstructor只能获取public
        Constructor constructor = cls1.getConstructor(String.class);
        Object o2 = constructor.newInstance("地址");
        System.out.println("公共化有参"+o2);
        //私有有参 无法实例,但在反射机制中可以通过getDeclaredConstructor获取全部方法,再利用不同形参选中构造器
        Constructor con = cls1.getDeclaredConstructor(String.class,int.class);
        //这里报有非法进入异常,由于私有化机制问题,可以修改不检查访问.
        con.setAccessible(true);
        Object o3 = con.newInstance("姓名",10);
        System.out.println("私有化有参"+o3);
        //普通或私有化属性与之相同, ,方法与此完全相同,包括static -> null
        Field field = cls1.getDeclaredField("number");
        field.setAccessible(true);
        field.set(null,40);//修改值,若是静态可将对象实例改为null
        System.out.println(field.get(null));//同理
    }
}
class Each{
    private String address;
    private String name;
    private int age;
    private static int number =20;
    public Each(){//无参构造器
    }
    public Each(String address){//Each的公共有参构造器
        this.address = address;
    }
    private Each(String name,int age){//Each的私有化构造器
        this.name = name;
        this.age = age;
    }
}
