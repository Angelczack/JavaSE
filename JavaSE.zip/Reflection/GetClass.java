package Ataraxia.JavaSE.Reflection;

import java.io.Serializable;
import java.util.Enumeration;

public class GetClass {//获取Class对象的方法 :6种
    public static void main(String[] args) throws ClassNotFoundException {
        //编译阶段 Class.forName  通过配置文件或完整路径获取
        String add = "Ataraxia.Reflection.Cat";
        Class cls1 = Class.forName(add);
        System.out.println(cls1);
        //类加载阶段  类名.class  用于参数传递
        Class cls2 = Cat.class;
        System.out.println(cls2);
        //运行阶段  类对象.getClass  用于有对象实例
        Cat cat = new Cat();//运行阶段
        Class cls3 = cat.getClass();
        System.out.println(cls3);
        //通过类加载器获取
        //(1)先得到类的对象实例
        ClassLoader classLoader1 = cat.getClass().getClassLoader();
        System.out.println(classLoader1);
        //(2)先获取类加载器对象,再通过地址获取
        Class cls4 = classLoader1.loadClass(add);
        //cls1,cls2,cls3,cls4是同一对象
        System.out.println("============");
        /*以下都有Class对象:
        1.外部类,成员内部类,静态内部类,局部内部类,匿名内部类
        2. interface:接口
        3.数组
        4.enum:枚举
        5.annotation:注解
        6.基本数据类型
        7. void
         */
        Class<String> class1 = String.class;
        Class<Serializable> class2 = Serializable.class;
        Class<Integer[]> class3 = Integer[].class;//一维
        Class<float[][]> class4 = float[][].class;//二维
        Class<Enumeration> class5 = Enumeration.class;
        Class<Deprecated> class6 = Deprecated.class;
        Class<Long> class7 = Long.class;
        Class<Void> class8 = void.class;
    }
}

