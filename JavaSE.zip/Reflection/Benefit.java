package Ataraxia.JavaSE.Reflection;

import java.lang.reflect.Method;
import java.util.Scanner;

public class Benefit {
    //反射机制的好处:(动态加载)：没有运行到对应类时不会异常,只有运行时异常,大大降低了依赖性
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("please enter a key:");
        String key = sc.next();
        switch(key){
            case "1": //Car car = new Car();  当编译阶段未创建类时,会直接报错  (静态加载)
                break;
            case "2"://利用反射机制,创建一个不存在的类
                //输入1时不会报错 输入2时运行报错
                Class cls = Class.forName("Person");
                Object o = cls.newInstance();
                Method method = cls.getMethod("person");
                method.invoke(o);
        }
    }
}
