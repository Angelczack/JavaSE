package Ataraxia.JavaSE.Reflection;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.Properties;
/*1.在运行时判断任意一个对象所属的类
2.在运行时构造任意一个类的对象
3.在运行时得到任意一个类所具有的成员变量和方法
4.在运行时调用任意一个对象的成员变量和方法
5.生成动态代理

 */
/*自我理解:  将一个类比喻成下方的Cat
    当一个类(Cat)加载时会进入Class类加载阶段,然后在Cat类创建一个对象与Class类中对应对象产生关系,
    此时class对象就像是Cat类对象的镜子,但是Class类中没有Cat对应的方法、变量、构造器等,所以统一起来,
    方法就是method,变量就是field,构造器就是constructor等,当传统调用Cat类中变量、方法时,都是对象.变量~
    ,而镜子Class类则是相反：变量、方法~.Class类对象  并且Class类的本质其实还是Cat类
 */
//提高效率，取消访问检查   名.setAccessible(true);
public class elements {//反射基础入门原理
    public static void main(String[] args) throws Exception {
        //传统调用Cat中的hi方法是创建对象.调用
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\re.properties"));//加载文件
        //获取值并转为字符串形式,这里的classfullpath连接着Cat类
        String classfullpath = properties.getProperty("classfullpath").toString();
        //同理,这里的methodName连接着Cat中的hi
        String methodName = properties.getProperty("method").toString();
        System.out.println("classfullpath="+classfullpath);
        System.out.println("methodName="+methodName);

        //反射:通过外部文件的修改控制程序,不用修改大量的源码
        //加载类,返回class类型的对象cls
        Class cls = Class.forName(classfullpath);
        //通过cls得到你加载类cat的对象实例
        Object o = cls.newInstance();//本质上其实是 Cat类创建一个引用对象
        System.out.println("o的运行类型="+o.getClass());
        //通过cls得到你加载类cat的hi方法,再将方法视为对象(万物皆对象)
        Method method = cls.getMethod(methodName);//这里将变量转为方法(hi)
        System.out.println("证明：class类的method还是Cat中的方法:"+method);
        //通过method调用方法:即通过方法对象来实现调用方法
        method.invoke(o);//反射机制:  方法.invoke(对象)
    }
}
class Cat{
    //properties文件中引用了Cat类
    String name = "布偶猫";
    public void hi(){
        System.out.println(name+"打招呼");//常用方法
    }
}
