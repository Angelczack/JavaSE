package Ataraxia.JavaSE.Reflection;

public class ClassLoading {//类加载的5各阶段
    public static void main(String[] args) {
        /*1.加载阶段:加载A类并生成A的class对象
          2.连接阶段:
                (1)验证
            为了确保Class文件的字节流中包含的信息符合当前虚拟机的要求,包括:文件格式验证、字节码验证等,
            当项目过大时,可以使用 Xverify:none 参数来关闭验证措施,缩短类加载时间
                (2)准备
            JVM会在该阶段对 静态变量 、分配内存并默认初始化,如对应的0、null、false等,这些变量使用的内存会在方法区中进行分配
            实例变量和final修饰的常量无法初始化,还是原始值
                (3)解析
            JVM虚拟机将常量池内的符号引用替换为直接引用的过程,此阶段由虚拟机自执行
          3.初始化阶段
            此阶段真正开始执行类中定义的java代码并执行<clinit>()方法
            其方法会依次收集类中的所有静态变量的赋值动作和静态代码块中的语句,并进行合并
            例如:下方代码  合并后 : num=20;
         */
        new A();
    }
}
class A{
    static{
        System.out.println("静态代码块");
        num = 50;
    }
    public static int num = 20;
    //(final)int num =20  无法初始化为0
    public A(){
        System.out.println("A的构造器");
    }
}
