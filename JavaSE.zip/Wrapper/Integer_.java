package Ataraxia.JavaSE.Wrapper;
import java.lang.Integer;
public class Integer_ {//Int的包装类
    //八大包装类：Byte,Short,Int,Long,Double,Float(父类:Number);Boolean,Character
    public static void main(String[] args) {
        /*关于装箱与拆箱;(其他包装类的拆装与之相同)
            装箱:int->integer
            拆箱:integer->int
         */
//        装箱:
//        int n1 = 10;
//        Integer integer = n1;
//        底层调用:Integer integer = Integer.valueOf(n1);
//              或:Integer integer = new Integer(n1);
//
//        拆箱:
//        int n2 = integer;
//        底层调用:int n2 = integer.intValue();
        System.out.println("==Integer(包装类)->String====");
        System.out.println("第一种方法");
        Integer n1 = 100;
        String str1 = n1 + "";

        System.out.println("第二种方法");
        String str2 = n1.toString();

        System.out.println("第三种方法");
        String str3 = String.valueOf(n1);

        System.out.println("==String->Integer(包装类)====");
        System.out.println("第一种方法");
        String str = "123";
        Integer n2 = Integer.parseInt(str);

        System.out.println("第二种方法");
        Integer n3 = new Integer(str);
    }
}
