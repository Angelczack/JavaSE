package Ataraxia.JavaSE.Enumeration;

public class EnumerationP {
    //枚举类:当一个类有固定的常量，我们不需要主动修改它，譬如季节(四个)
    //注：枚举类隐式继承Enum类，所以无法继承其他类，但是可以实现接口
    public static void main(String[] args) {
        System.out.println(Season.SUMMER);//枚举类中的常量调用自带static和final，所以可以直接调用
        System.out.println(Season.WINTER);

        /*  enum枚举类的一些成员方法：
            1.name() 创建枚举属性对象引用，返回常量名
            2.ordinal()创建枚举属性对象引用，返回在所有常量属性中0开始的编号
            3.values()直接创建数组对象，需要循环返回枚举属性所有值
            4.valueOf()在对象构造器中输入字符串，返回对应常量名属性值，若无则报错
            5.compareTo()用法与equals一致，用左边编号减去右边编号
         */
        System.out.println("===========");
        Season autumn = Season.AUTUMN;
        System.out.println("name方法："+autumn.name());
        System.out.println("ordinal方法："+autumn.ordinal());
        Season[] add = Season.values();
        for(Season season : add){//增强for循环，将:右边值依次赋予左边
            System.out.println("增强for:"+season);
        }
        Season summer = Season.valueOf("SUMMER");
        System.out.println("valueOf方法："+summer);
        System.out.println("compareTo方法："+Season.SPRING.compareTo(Season.AUTUMN));
    }
}
enum Season{/*枚举类：1.将class换位enum关键字;2.语法：常量名(构造器属性); (有多个常量时，用","隔开)
                3.语句位于首位，在属性前;
            */
    SPRING("春天"),AUTUMN("秋天"),SUMMER("夏天"),WINTER;//无参构造器
    private String name;

    /*自定义枚举类:1.将构造器私有化，防止new;2.删除set防止更改;3.在类中创建对象
                4.添加static直接调用，final固定常量
        注：常量名大写
     */
//    public static final Season SPRING = new Season("春天");
//    public static final Season SUMMER = new Season("夏天");
//    public static final Season AUTUMN = new Season("秋天");
//    public static final Season WINTER = new Season("冬天");

    private Season(){//无参构造器调用时，可以简化为  常量名;

    }

    private Season(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Season{" +
                "name='" + name + '\'' +
                '}';
    }
}
