package Ataraxia.JavaSE.TankGame;

import java.util.Vector;

public class Enemy extends TankModel implements Runnable{//敌人的坦克
    boolean isLive = true;//判断子弹击中敌方坦克是否存活
    Vector<Shoot> enemyShoot = new Vector<>();//将子弹集合存在这里
    public Enemy(int x, int y) {
        super(x, y);
    }
    //实现    敌方坦克随机移动
    public void run(){
        while(true){
            if(isLive && enemyShoot.size()<1){
                Shoot s = null;
                switch (getDirect()){//坦克在改变方向时,自动发射一颗子弹
                    case 0 :
                        s = new Shoot(getX()+20,getY(),0);
                        break;
                    case 1:
                        s = new Shoot(getX()+60,getY()+20,1);
                        break;
                    case 2:
                        s = new Shoot(getX()+20,getY()+60,2);
                        break;
                    case 3:
                        s = new Shoot(getX(),getY()+20,3);
                        break;
                }
                enemyShoot.add(s);
                new Thread(s).start();
            }
            switch(getDirect()){
                case 0 ://循环走三十步,再换方向
                for (int i = 0; i < 30; i++) {
                    if(getY()>0) {
                        Moveup();
                    }
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                case 1 :
                    for (int i = 0; i < 30; i++) {
                        if(getX()+60 < 1000) {
                            MoveRight();
                        }
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                case 2 :
                    for (int i = 0; i < 30; i++) {
                        if(getY()+60 < 800) {
                            MoveDown();
                        }
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                case 3 :
                    for (int i = 0; i < 30; i++) {
                        if(getX()>0) {
                            MoveLeft();
                        }
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
            }
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //给予随机方向
            int direct = (int)(Math.random()*4);
            setDirect(direct);
            if(!isLive){//如果坦克被打死,则退出程序
                break;
            }
        }
    }
}
