package Ataraxia.JavaSE.TankGame;

import java.util.Vector;

public class Missile extends TankModel{//我的导弹式坦克
    Shoot shoot = null;
    boolean isLive = true;
    Vector<Shoot> shoots = new Vector<>();
    public Missile(int x, int y) {//用于接收坦克坐标
        super(x, y);
    }
    public void shoot(){//由本坦克启动射击模式
        if(shoots.size() == 5)//限制子弹数量
            return;
        switch (getDirect()){//获取本坦克方向,子弹方向随坦克改变(坦克管)
            //子弹从坦克管的初始位置出来
            case 0 : shoot = new Shoot(getX()+20,getY(),0);
            break;
            case 1 : shoot = new Shoot(getX()+60,getY()+20,1);
            break;
            case 2 : shoot = new Shoot(getX()+20, getY()+60,2);
            break;
            case 3 : shoot = new Shoot(getX(),getY()+20,3);
            break;
        }
        shoots.add(shoot);//添加多个子弹
        new Thread(shoot).start();//由坦克来启动射击线程
    }
}
