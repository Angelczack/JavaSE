package Ataraxia.JavaSE.TankGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Vector;

public class MyPanel extends JPanel implements KeyListener,Runnable {//我的画板类继承java画板并实现键盘输入接口
    Missile missile = null;//初始化坦克
    //敌人的坦克有多个,创建一个集合,由于后续的多线程，这里采用Vector集合
    Vector<Enemy> enemyTanks = new Vector<>();
    Vector<Bomb> bombs = new Vector<>();
    int enemySize = 30;//设置坦克的数量为3个
    private int direct = 0;
    Image image1 = null;
    Image image2 = null;
    Image image3 = null;//初始化
    public MyPanel(){
        //如果在paint方法里,每调用一次paint方法就会重置坐标
        missile = new Missile(100,300);//创建坦克初始坐标
        for (int i = 0; i < enemySize; i++) {
            Enemy enemy = new Enemy(100*(i+1),0);//初始化敌人坦克坐标
            enemy.setDirect(2);
            new Thread(enemy).start();
            //初始化子弹坐标
            Shoot enemyShoot = new Shoot(enemy.getX()+20,enemy.getY()+60,enemy.getDirect());
            enemy.enemyShoot.add(enemyShoot);//循环往集合中添加子弹
            new Thread(enemyShoot).start();
            enemyTanks.add(enemy);//循环添加敌人坦克
//            image1 = Toolkit.getDefaultToolkit().getImage(MyPanel.class.getResource("/1.png"));
//            image2 = Toolkit.getDefaultToolkit().getImage(MyPanel.class.getResource("/2.png"));
//            image3 = Toolkit.getDefaultToolkit().getImage(MyPanel.class.getResource("/3.png"));
        }
    }
    //继承画板,重写paint方法
    @Override
    public void paint(Graphics g){//我的画笔
        super.paint(g);
        g.fillRect(0,0,1000,800);//填充整个画板，默认黑色
        if(missile!=null && missile.isLive){
            MyTank(missile.getX(),missile.getY(),g,missile.getDirect(),1);//传入
        }

        for (int i = 0; i < missile.shoots.size(); i++) {
                Shoot shoot = missile.shoots.get(i);
            if(shoot!=null && shoot.isLive==true) {
                //画出子弹
                g.fill3DRect(shoot.x, shoot.y, 3, 3, false);
            }else{
                missile.shoots.remove(shoot);
            }
        }
        for (int i = 0; i < bombs.size(); i++) {
            Bomb bomb = bombs.get(i);
            //图片随血量变少而变化,视觉形成动态图片
            if(bomb.blood > 6)
                g.drawImage(image1,bomb.x,bomb.y,60,60,this);
            if(bomb.blood > 3)
                g.drawImage(image2,bomb.x,bomb.y,60,60,this);
            else
                g.drawImage(image3,bomb.x,bomb.y,60,60,this);
            bomb.isBomb();//调用血量减少的方法
            if(bomb.blood == 0) {
                bombs.remove(bomb);//最后图片定格,当产生爆炸,取出图片达到消失效果
            }
        }

        for (int i = 0; i < enemyTanks.size(); i++) {//循环遍历
            Enemy enemy = enemyTanks.get(i);//将敌人坦克取出
            if(enemy.isLive == true) {
                MyTank(enemy.getX(), enemy.getY(), g, enemy.getDirect(), 0);//调用坦克方法
                for (int j = 0; j < enemy.enemyShoot.size(); j++) {
                    Shoot shoot = enemy.enemyShoot.get(j);//循环取出子弹
                    if (shoot.isLive) {
                        //画出子弹
                        g.fill3DRect(shoot.x, shoot.y, 3, 3, false);
                    } else {
                        enemy.enemyShoot.remove(shoot);
                    }
                }
            }
        }

        showKill(g);
    }
    public void showKill(Graphics g){//编写方法,显示击杀敌方坦克的数量
        g.setColor(Color.black);
        Font font = new Font("宋体",Font.BOLD,25);
        g.setFont(font);
        g.drawString("您累积击毁敌方坦克",1020,30);
        //画出敌方坦克
        MyTank(1020,60,g,0,0);
        g.setColor(Color.black);
        g.drawString("0",1080,100);
    }

    /**
     *
     * @param x
     * @param y
     * @param g
     * @param direct 方向 上下左右
     * @param type 类型：敌人和自己的坦克
     */
    //为自己的坦克创建新方法
    public void MyTank(int x,int y,Graphics g,int direct,int type){
        switch (type) {
            case 0: g.setColor(Color.cyan);
            break;
            case 1: g.setColor(Color.yellow);
            break;
        }
        switch(direct) {
            case 0: //表示上
                g.fill3DRect(x, y, 10, 60, false);//坦克左轮
                g.fill3DRect(x + 30, y, 10, 60, false);//坦克右轮
                g.fill3DRect(x + 10, y + 10, 20, 40, false);//坦克中枢
                g.fillOval(x + 10, y + 20, 20, 20);//坦克圆形盖子
                g.drawLine(x + 20, y , x + 20, y+30);//坦克的直线炮管
                break;
            case 1://表示右
                g.fill3DRect(x, y, 60, 10, false);//坦克左轮
                g.fill3DRect(x , y+30, 60, 10, false);//坦克右轮
                g.fill3DRect(x + 10, y + 10, 40, 20, false);//坦克中枢
                g.fillOval(x + 20, y + 10, 20, 20);//坦克圆形盖子
                g.drawLine(x + 60, y + 20, x+30 , y+ 20);//坦克的直线炮管
                break;
            case 2://表示下
                g.fill3DRect(x , y, 10, 60, false);//坦克左轮
                g.fill3DRect(x+30, y, 10, 60, false);//坦克右轮
                g.fill3DRect(x + 10, y + 10, 20, 40, false);//坦克中枢
                g.fillOval(x + 10, y + 20, 20, 20);//坦克圆形盖子
                g.drawLine(x + 20, y + 60, x + 20, y+30);//坦克的直线炮管
                break;
            case 3://表示左
                g.fill3DRect(x, y, 60, 10, false);//坦克左轮
                g.fill3DRect(x , y+30, 60, 10, false);//坦克右轮
                g.fill3DRect(x + 10, y + 10, 40, 20, false);//坦克中枢
                g.fillOval(x + 20, y + 10, 20, 20);//坦克圆形盖子
                g.drawLine(x, y + 20, x+30 , y+ 20);//坦克的直线炮管
                break;
        }
    }
    public void hitEnemyTank(){
        if(missile.shoot!=null && missile.shoot.isLive){//前提是子弹还存在
            for (int i = 0; i < enemyTanks.size(); i++) {
                Enemy enemy = enemyTanks.get(i);//循环取出
                hitTank(missile.shoot,enemy);
            }
        }
    }
    @Override
    public void keyTyped(KeyEvent e) {//输入键盘的字符

    }

    @Override
    public void keyPressed(KeyEvent e) {//键盘按下所触发的事件
        if(e.getKeyCode() == KeyEvent.VK_W) {
            missile.setDirect(0);
            if(missile.getY() > 0) {
                missile.Moveup();
            }
        }
        else if(e.getKeyCode() == KeyEvent.VK_D) {
            missile.setDirect(1);
            if(missile.getX()+60 < 1000) {
                missile.MoveRight();
            }
        }
        else if(e.getKeyCode() == KeyEvent.VK_S) {
            missile.setDirect(2);
            if(missile.getY()+ 60 <800) {
                missile.MoveDown();
            }
        }
        else if(e.getKeyCode() == KeyEvent.VK_A) {
            missile.setDirect(3);
            if(missile.getX() > 0) {
                missile.MoveLeft();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_J){
            missile.shoot();
        }
        this.repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {//键盘松开所触发的事件

    }
    public void run(){//将画板设置成一个线程与shoot线程同步运行,实现子弹的重绘
        while(true) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            hitEnemyTank();
            hitMissile();
            this.repaint();
        }
    }
    public void hitMissile(){//敌方坦克命中我方坦克
        for (int i = 0; i < enemyTanks.size(); i++) {
            Enemy enemyTank = enemyTanks.get(i);
            for (int j = 0; j < enemyTank.enemyShoot.size(); j++) {
                Shoot shot = enemyTank.enemyShoot.get(j);
                if(missile.isLive && shot.isLive){
                    hitTank(shot,missile);
                    }
            }
        }
    }
    public void hitTank(Shoot shot,TankModel enemyTank){//我方坦克击中敌方坦克
        //判断子弹坐标是否在敌方坦克范围内,上下、左右两对不同范围
        switch (enemyTank.getDirect()) {
            case 0:
            case 2:
                if(shot.x>enemyTank.getX() && shot.x<enemyTank.getX()+40
                        && shot.y>enemyTank.getY() && shot.y<enemyTank.getY()+60){
                    shot.isLive = false;
                    enemyTank.isLive = false;//当子弹射向敌方坦克时，子弹和坦克都应该结束生命周期
                    enemyTanks.remove(enemyTank);//当子弹射向敌方坦克时，移除坦克
                    //当坦克被击中时,爆炸效果的初始坐标
                    Bomb bomb = new Bomb(enemyTank.getX(), enemyTank.getY());
                    bombs.add(bomb);
                }
            case 1:
            case 3:
                if(shot.x>enemyTank.getX() && shot.x<enemyTank.getX()+60
                        && shot.y>enemyTank.getY() && shot.y<enemyTank.getY()+40){
                    shot.isLive = false;
                    enemyTank.isLive = false;//当子弹射向敌方坦克时，子弹和坦克都应该结束生命周期
                    enemyTanks.remove(enemyTank);//当子弹射向敌方坦克时，移除坦克
                    //当坦克被击中时,爆炸效果的初始坐标
                    Bomb bomb = new Bomb(enemyTank.getX(), enemyTank.getY());
                    bombs.add(bomb);
                }
        }
    }
}
