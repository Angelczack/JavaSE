package Ataraxia.JavaSE.TankGame;

public class Shoot implements Runnable{//将子弹设置为一个线程
    //坦克射出子弹的坐标、方向和速度
    int x;
    int y;
    int direct;
    private int speed = 50;//子弹原速度
    boolean isLive = true;//判断子弹是否存在(生命周期)
    public Shoot(int x, int y, int direct) {
        this.x = x;
        this.y = y;
        this.direct = direct;
    }
    public void run(){
        while(true) {
            try {
                Thread.sleep(50);//子弹需要慢慢的移动
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //根据方向移动
            switch (direct){
                case 0 : y-=speed;
                break;
                case 1 : x+=speed;
                break;
                case 2 : y+=speed;
                break;
                case 3 : x-=speed;
            }
            if(!((x>=0 && x<=1000) && (y>=0 && y<=800) && isLive)) {//当子弹碰到边界时,自动销毁
                isLive = false;
                break;
            }
        }
    }
}
