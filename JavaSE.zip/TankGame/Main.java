package Ataraxia.JavaSE.TankGame;

import javax.swing.*;
import java.awt.*;
public class Main extends JFrame {//继承画框
    private MyPanel myPanel = null;
    public static void main(String[] args) {
        new Main();
    }

    public Main(){
        //创建面板
        myPanel = new MyPanel();
        this.add(myPanel);//由面板启动画板线程
        Thread thread = new Thread(myPanel);
        thread.start();
        this.setSize(1300,800);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.addKeyListener(myPanel);//添加监听键盘的事件，即可以监听到面板发生的键盘事件
    }
}
