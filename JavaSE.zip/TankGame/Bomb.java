package Ataraxia.JavaSE.TankGame;

public class Bomb {//坦克爆炸效果
    int x;
    int y;
    boolean isLive = true;
    int blood = 9;//血量初始为9

    public Bomb(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public void isBomb(){
        if(blood > 0){//血量逐渐变少
            blood--;
        }else{
            isLive = false;
        }
    }
}
