package Ataraxia.JavaSE.TankGame;

public class TankModel {//坦克参照物,坦克基本数值类,敌人和自己的坦克都继承此类
    private int X;
    private int Y;//坐标
    private int direct;//方向,定义在这里,好处：复用
    boolean isLive = true;
    //将移动坐标包装成一个方法,在键盘监听事件中调用
    public void Moveup(){
        Y -= 5;
    }
    public void MoveRight(){
        X += 5;
    }
    public void MoveDown(){
        Y += 5;
    }
    public void MoveLeft(){
        X -= 5;
    }
    public int getDirect() {
        return direct;
    }
    //
    public void setDirect(int direct) {
        this.direct = direct;
    }

    public TankModel(int x, int y) {
        X = x;
        Y = y;
    }

    public int getX() {
        return X;
    }

    public void setX(int x) {
        X = x;
    }

    public int getY() {
        return Y;
    }

    public void setY(int y) {
        Y = y;
    }
}
