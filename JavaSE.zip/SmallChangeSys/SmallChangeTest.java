package Ataraxia.JavaSE.SmallChangeSys;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class SmallChangeTest {
    //所有的属性
    int number;
    SimpleDateFormat da = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    //将日期格式转换为2020-01-02 17:00的格式
    Date date;
    double  revenue;//收入金额
    double balance=0.0;//收入余额
    double expenditure;//消费金额
    String interpret;//消费说明
    double money=0.0;//消费余额
    char yn;//输入是否退出的指令
    String detail = "--------零钱通明细---------\n";
    boolean whether = true;//布尔类型判断,退出时后可执行false
    Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        SmallChangeTest smallChangeTest = new SmallChangeTest();
        smallChangeTest.DisplayMain();
    }

    public void DisplayMain() {//主菜单展示

        do {//写一个循环，每次执行完数字所行的页面，最后可继续输入执行
            //先将菜单展示
            System.out.print("-------------------");
            System.out.print("零钱通菜单");
            System.out.println("-------------------");
            for (int i = 0; i < 4; i++) {
                System.out.print("\t\t\t\t");
                if (i == 0) System.out.println("1 零钱通明细");
                if (i == 1) System.out.println("2 收益入账");
                if (i == 2) System.out.println("3 消费");
                if (i == 3) System.out.println("4 退\t出");
            }
            System.out.print("请选择(1-4):");
            number = scanner.nextInt();//所选择的数字
            //switch进行判断
            date = new Date();//获取日期
            switch (number) {
                case 1:
                    this.NumberOne();
                    break;
                case 2:
                    this.NumberTwo();
                    break;
                case 3:
                    this.NumberThree();
                    break;
                case 4:
                    this.NumberFour();
                    break;
                default:
                    System.out.println("输入有误，请重新输入");
            }
        }while(whether);
    }

    public void NumberOne(){
        //菜单1的功能
        System.out.println(detail);
    }
    public void NumberTwo(){
        //菜单2的功能
        System.out.print("收入金额:");
        revenue = scanner.nextDouble();//收益

        //写出错误条件，跳过执行，返回菜单
        if(revenue<=0) {
            System.out.println("入账金额错误，强制返回菜单");
            return;
        }
        balance += revenue;//余额需要叠加
        detail += "\n收益入账  +" + revenue + " " + da.format(date) + "\t余额:" + balance;
    }
    public void NumberThree(){
        //菜单3的功能
        System.out.print("消费金额：");
        expenditure = scanner.nextDouble();
        if(expenditure<=0 || expenditure>balance){
            System.out.println("消费金额错误，您的金额仅在0-"+balance+"之间");
            return;
        }
        System.out.print("消费说明:");
        interpret = scanner.next();
        balance-=expenditure;
        detail +="\n"+interpret+"   -"+expenditure+" "+da.format(date)+" "+"\t余额:"+balance;
    }
    public void NumberFour(){
        //菜单4的功能
        while(true){
            System.out.println("你确定要退出吗？y/n");
            yn = scanner.next().charAt(0);
            if (yn == 'n' || yn == 'y') {
                break;
            }
        }
        if(yn == 'y'){
            System.out.println("------退出零钱通------");
            whether = false;
        }
    }
}