package Ataraxia.JavaSE.File;

public class AboutCreate {//文件/文件夹创建:在e盘下创建三个文件
    /*1.new File(String pathname)  //根据路径创建一个file对象
        String create = "e:\\file1.txt";
        File file1 = new File(create);
        file1.createNewFile();

      2.new file(File parent,String child)  //根据父目录文件+子路径构建
        File fileC = new File("e:\\");
        String create = "file2.txt";
        File file2 = new File(fileC,create);
        file2.createNewFile();

      3.new file(String parent,String child)  //根据父目录+子路径构建
        String parent = "e:\\";
        String child = "file3.txt";
        File file3 = new File(parent,child);
        file3.createNewFile();
     */
}
