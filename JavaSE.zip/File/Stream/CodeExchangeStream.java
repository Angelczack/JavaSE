package Ataraxia.JavaSE.File.Stream;

import java.io.*;

public class CodeExchangeStream {
    //编码转换处理流,因为字符乱码问题或处理纯文本数据时,使用字符流效率更高,所以可以将字节流转换为字符流
    public static void main(String[] args) throws IOException {
        //1.InputStreamReader:Reader的子类,可以将InputStream(字节流)包装成(转换)Reader(字符流)
        //2.OutputStreamWriter:Writer的子类,实现将OutputStream(字节流)包装成(转换)Writer(字符流)
        String address = "E:\\idea-java\\Stream\\CodeExchange.txt";
        //读取并创建一个gbk编码的文件  InputStreamReader只是转换编码,操作还是需要处理流
        BufferedReader br =
        new BufferedReader(new InputStreamReader(new FileInputStream(address),"gbk"));
        BufferedWriter bs =
        new BufferedWriter(new OutputStreamWriter(new FileOutputStream(address),"UTF-8"));
        bs.write("java最强!");
        String readLine = br.readLine();
        System.out.println(readLine);
        System.out.println("成功运行~");
        br.close();
        bs.close();
    }
}
