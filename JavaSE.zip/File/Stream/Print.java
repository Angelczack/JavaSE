package Ataraxia.JavaSE.File.Stream;

import java.io.IOException;
import java.io.PrintStream;

public class Print {//打印只有输出流,没有输入流
    //字符输出流 PrintWriter 用法与之一样
    public static void main(String[] args) throws IOException {
        PrintStream print1 = System.out;//字节输出流
        PrintStream print2 = new PrintStream(System.out);
        //创建性质都一样,也可以同时创建文件new PrintStream(new File..());
        print1.println("john");//直接输出
        print1.write("hello".getBytes());//字节输出
        //修改输出流的输出位置 到Print.txt中去
        System.setOut(new PrintStream("E:\\idea-java\\Stream\\Print.txt"));
        System.out.println("写入到本文件中去");//写入
        print1.close();
    }
}
