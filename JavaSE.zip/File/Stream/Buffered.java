package Ataraxia.JavaSE.File.Stream;

import java.io.*;

public class Buffered {
    /*输入输出方法一致,它是处理流(包装流),
      可以将只要是Reader或Writer的子类节点流封装到一起(BufferedReader与BufferedWriter也是其子类)
     */
    //BufferedOutputStream与BufferedWriter一样,前者是字节处理流,后者是字符处理流;前者更适合二进制文件
    //例如：声音，图片，视频,其是InputStream和OutputStream子类
    public static void main(String[] args) throws IOException {
        String address1 = "E:\\idea-java\\Stream\\1.jpg";//被拷贝的文件
        String address2 = "E:\\idea-java\\Stream\\Copy.jpg";//拷贝后的文件地址名
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {//将原有文件字节输入到程序中
            bis = new BufferedInputStream(new FileInputStream(address1));
            //将程序备份输出到文件中
            bos = new BufferedOutputStream(new FileOutputStream(address2));
            byte bytes[] = new byte[1024];//一次性读取1024个字节
            int readLen = 0;
            while((readLen=bis.read(bytes))!=-1){//方法运行完自动返回-1
                bos.write(bytes,0,readLen);//输出
            }
            System.out.println("运行成功~");
        } catch (IOException e) {
            e.printStackTrace();
        }finally {//将流关闭
            bis.close();
            bos.close();
        }
    }
}
