package Ataraxia.JavaSE.File.Stream;

import java.io.*;

public class ObjectPutStream {
    /*1.一般的流保存的都是值,而这个是对象处理流;保存的是(数据类型/对象+值),其被称为序列号;
      2.通过(数据类型/对象+值)而恢复数据的被称为  反序列化。例如一个1.1值有double或者float无法分辨
      3.需要让某个对象支持序列化机制,则必须让其类是可序列化的,因此必须实现两个接口之一
       (1).Serializable  这是一个标记接口:不需要重写方法
       (2).Externalizable
      4.序列化后,保存的文件格式,不是存文本,而是按照它的格式来存.所以可能是乱码

    details:
        1.static 和 transient修饰的成员无法被序列化 ; transient:作用就是无法被序列化且只能修饰变量
        2.序列化后的类,其所有除上两个修饰的成员外都会默认序列化,所以若类内定义了没有实现序列化接口的对象将会报错
        3.序列化具有可继承性,父类实现序列化接口后,子类也默认实现了序列化;例如:Integer父类Number实现了接口
    */
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        OutputStream();
        InputStream();
    }
    static void OutputStream() throws IOException{
        String address = "e:\\idea-java\\Stream\\ObjectPutStream.txt";
        //处理流需要包装其他同父类中的子类
        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(address));
        stream.writeInt(100);//int -> Integer 自动实现了Serializable
        stream.writeUTF("钱");//String为引用类型,方法不一样
        stream.writeObject(new Dog("旺财",2));//对象需手动实现接口
        stream.close();
        System.out.println("成功运行~");
    }
    static void InputStream() throws IOException, ClassNotFoundException {
        String address = "e:\\idea-java\\Stream\\ObjectPutStream.txt";
        //与对象输出流一致
        ObjectInputStream stream = new ObjectInputStream(new FileInputStream(address));
        //读取(反序列化)的顺序必须与保存数据(序列化)的顺序一致
        System.out.println(stream.readInt());
        System.out.println(stream.readUTF());
        System.out.println(stream.readObject());
        stream.close();
    }
}
class Dog implements Serializable {
    static int a;
    transient int b;
    private static final long SerialVersionUID = 1L;//添不添加无所谓,序列化的版本号,可以提高兼容性
    private String name;
    private int age;

    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
