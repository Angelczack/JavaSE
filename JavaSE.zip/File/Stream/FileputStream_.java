package Ataraxia.JavaSE.File.Stream;
//flush只能用于字符流,且flush是一直刷新,刷新后还可以使用;而close是直接关闭,但在关闭之前会自动刷新一次,所以flush无法完全替代close
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
 //!FileReader 和 FileWriter 与FileInputStream 和 FileOutputStream 大部分都相同  区别在于前者是字符流 后者是字节流
//字符流方法关闭会返回null,字节流则返回-1
/*!BufferedWriter 和 BufferedReader 输入输出方法一致,它是处理流(包装流),之前的都是节点流
    可以将只要是Reader或Writer的子类节点流封装到一起完成实现,好处是效率高,操作不繁琐,复用率高 与集合概念相像
 */
public class FileputStream_ {//由InputStream字节流所衍生出来的派生类
    public static void main(String[] args) {
            new FileputStream_().input();
        }
    public void input(){
        //新:创建数组,一次读取十五个字节   数组字节读取汉字时,不会乱码
        //原因:添加前一次读取一个会将汉字拆分为3个字节,读取后无法组成一个汉字
        byte bytes[] = new byte[15];
        String str = "hello";
        String file = "E:\\idea-java\\Stream\\Hello.txt";//创建文本
        File directory = new File(file);
        try {
            directory.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileInputStream fileInputStream = null;
        FileOutputStream fileOutputStream = null;
        int readDate = 0;
        try{
            fileInputStream = new FileInputStream(directory);//将文件输入到程序中
            fileOutputStream = new FileOutputStream(file,true);//将程序输出到文件中
            // ,并会覆盖原来的字符,后面加true则不会
            fileOutputStream.write(str.getBytes());//传入字符数组
            while((readDate = fileInputStream.read(bytes)) != -1) {//新加:bytes,一次读取15个字节
                //一次读取一个,所以循环读取字节,当读取完毕会自动关闭方法并返回-1
                //System.out.print((char) readDate);//转换成文本里的字符并输出   新:
                System.out.println(new String(bytes,0,readDate));
            }
        }catch(IOException e){
            e.printStackTrace();
        }finally {
            try {
                fileInputStream.close();//关闭流,否则会造成资源浪费，上面是自动关闭方法
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
