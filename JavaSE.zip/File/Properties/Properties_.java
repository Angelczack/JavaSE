package Ataraxia.JavaSE.File.Properties;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Properties_ {
    //Properties的常用方法(集合HashTable的子类)
    public static void main(String[] args) throws IOException {
        //使用Properties类来读取 .properties文件
        //1.创建对象
        Properties properties = new Properties();
        //2.加载指定配置文件  load
        properties.load(new FileReader("src\\mysql.properties"));
        //3.把k-v显示控制台   list
        properties.list(System.out);
        //4.根据key获取对应值   getProperty
        String user = properties.getProperty("user");
        System.out.println("name:"+user);
        //5.修改值  setProperty
        properties.setProperty("id","abc111");
        //6.修改后需要将该值存储到文件中去  store
        properties.store(new FileOutputStream("src\\mysql.properties"),"hello");
        //"hello"是注解
    }
}
