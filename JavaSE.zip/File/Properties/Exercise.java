package Ataraxia.JavaSE.File.Properties;

import java.io.*;
import java.util.Properties;

public class Exercise {
    /*(1)要编写一个dog.properties  name=tom  age=5  color=red
        (2)编写Dog类(name,age.color)创建一个dog对象，读取dog.properties 用相应的内容完成属性初始化.并输出
        (3)将创建的Dog对象，序列化到文件dog.dat 文件

     */
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        String add = "src\\Dog.properties";
        Properties properties = new Properties();
        //加载properti文件
        properties.load(new FileReader(add));
        //用数据接收并传入到狗类中
        String name = properties.get("name") + "";
        int age = Integer.parseInt(properties.get("age") + "");
        String color = properties.get("color") + "";
        Dog dog = new Dog(name,age,color);
        System.out.println(dog);
        //创建对象输出处理流,序列化dog对象
        String address = "e:\\idea-java\\Stream\\Dog.txt";
        ObjectOutputStream outputStream =
                new ObjectOutputStream(new FileOutputStream(address));
        outputStream.writeObject(dog);
        System.out.println("序列化完成");
        outputStream.close();
        //执行反序列化
        ObjectInputStream inputStream =
                new ObjectInputStream(new FileInputStream(address));
        System.out.println(inputStream.readObject());
        System.out.println("反序列化完成");
        inputStream.close();
    }
}
class Dog implements Serializable{
    private String name;
    private int age;
    private String color;
    public Dog(String name, int age, String color) {
        this.name = name;
        this.age = age;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                '}';
    }
}
