package Ataraxia.JavaSE.OverRide;

// 1．编写一个Person类，包括属性/private (name、age)，构造器、方法say(返回自我介绍的字符串)。
// 2.编写一个Student类,继承Person类，增加id、score属性/private，以及构造器，定义say方法(返回自我介绍的信息)。
// 3.在main中,分别创建Person和Student对象，调用say方法输出自我介绍。
public class OverRideCase {

    public static void main(String... args){
        Person person = new Person("雷",18);
        Student student = new Student(210611,90);
        System.out.println(student.say());
    }
}
class Person{
    private String name;
    private int age;
    Person(String name,int age){
        this.name = name;
        this.age = age;
    }
    public String getName(){return name;}
    public int getAge(){return age;}
    Person(){}
    //重写：父类的返回修饰符必须比子类的小或一样  ,形参与重载不同必须一样，方法名和重载一样，一致
    //返回数据类型必须一样或父类为顶级父类object
    Object say(){//重写：父类返回值可以是子类的最高级或者相同
        return "My name is-"+name+"\tMy age is-" +age;
    }
}
class Student extends Person{
    private int id;
    private int score;
    Student(int id,int score){
        super();
        this.id = id;
        this.score = score;
    }
    @Override//注解：编译通过则必为重写
    protected String say(){//重写：返回修饰符子类必须比父类大或是相同
        return super.say()+"\tid-"+id+"\tscore-"+score;
    }
}
