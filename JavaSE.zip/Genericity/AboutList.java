package Ataraxia.JavaSE.Genericity;

import java.util.ArrayList;

public class AboutList {
    //若没有泛型的引用类型一般有默认<Object>,这就是为什么添加元素有:Object e提示
    //例如：List<Object> list = new Arraylist<>();
    //还有:class Tiger<Object>{Object o; public Tiger(Object e){}}
    public static void main(String[] args) {
 /* 作用:可以在类声明时通过一个标识标识类中某个属性的类型，或者是某个方法返回值的类型，或者是参数类型
    举例:创建一个类,随便定义一个泛型大写字母并<>起来
        然后创建对象定义泛型,传入对应泛型类型的值(随便什么,相当于替代声明类的泛型类型)
 */
        program<String> pro = new program<String>("对应泛型类型的值");
        program<Integer> pro2 = new program<Integer>(10);
        //通常在开发中，右边的泛型可以省略简写    program<Integer> pro2 = new program<>(10);
        program<BookShop> books = new program<>(new Book());//在给泛型指定具体类型后，可以传入该类型或者其子类类型
        //创建只能用 引用类型   例如：基本数据类型无法使用
        System.out.println(pro.method()+"\n对应integer的值"+pro2.method());
        //泛型:如果程序在编译时没有发出警告,运行时就不会产生类型转换异常
        ArrayList<animal> list = new ArrayList<animal>();
        //在这里添加类型:代表添加的对象只能是animal
        //可以添加不同的对象,所以不安全
        list.add(new animal("斑马"));
        list.add(new animal("麋鹿"));
        list.add(new animal("狮子"));
        //list.add(new Book());

        //遍历的时候需要类型转换调用其get方法,不同的对象有不同类型转换
        /*for(Object o : list){
         animal an = (animal)o;
         System.out.println(an.getName());
         }*/
        for(animal animal : list){
            //可以直接类名接收，不需要转换   !!提高了安全性和效率
            System.out.println(animal);
        }
    }
}
class animal{
    private String name;

    public animal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "animal{" +
                "name='" + name + '\'' +
                '}';
    }
}
class BookShop{

}
class Book extends BookShop{

}
class program<E>{//声明时定义
    E s;//可作为参数类型

    public program(E s) {//可作为构造器参数类型
        this.s = s;
    }
    public E method(){//可作为方法返回值
        return s;
    }
}
