package Ataraxia.JavaSE.Genericity;

import java.util.ArrayList;
import java.util.List;

public class AboutSymbol {
    public static void main(String[] args) {//通配符：<?>
        /*1.<?>:支持任意泛型类型
          2.<? extends A>:支持A类以及A类的子类,规定了泛型的上限
          3.<? super A>:支持A类以及A类的父类,不限于直接父类,规定了泛型的下限
         */
        
        List<Object> list1 = new ArrayList<>();
        List<A> list2 = new ArrayList<>();
        List<B> list3 = new ArrayList<>();
        List<C> list4 = new ArrayList<>();
        printCollection1(list1);//1、2、3、4都可以
        printCollection2(list3);//只能2、3、4
        printCollection3(list1);//只能1、2
    }
    public static void printCollection1(List<?> c){//1.
        for (Object o :c) {
            System.out.println(o);
        }

    }
        public static void printCollection2(List<? extends A> c){//2.
            for (Object o :c) {
                System.out.println(o);
            }
        }
        public static void printCollection3(List<? super A> c) {//3.
            for (Object o : c) {
                System.out.println(o);
            }
        }
}
class A{//父类

}
class B extends A{//A的子类

}
class C extends B{//B和A的子类

}
