package Ataraxia.JavaSE.Genericity;

public class CustomGeneric {
    public static void main(String[] args) {//自定义泛型类
        //调用泛型方法,传入的参数编译器会自动识别(自动装箱)
        new CustomGeneric().method("张三工资:",100);
    }
    //泛型方法
    public<U,M> void method(U u,M m){//<-定义后最好使用,不是调用
        System.out.println(u+""+m);
    }
}
class detail<E>{//关于自定义泛型类的细节
    E s;
    E[] ts;//1.可以声明数组,但不可以初始化  E[] ts = new ts[7];
    public void common_(E e){}//2.普通方法可以使用,静态方法不可以调用泛型属性
    //原因:静态在类加载时调用,而泛型定义是在类创建后
    //public static void static_(E e){}

    //注意事项：关于泛型方法：以下不是泛型方法，而是使用了类声明的泛型类型
    public void method(E e){}
}
interface IA<T,R>{//泛型接口:细节与泛型类同样
    void method();
}
interface IO extends IA<Double,Integer>{//继承泛型接口可以实现，引用类型
    }
    class M implements IO{
        public void method(){}//继承子类实现父类接口的抽象方法,这是抽象类的语法特性
    }

