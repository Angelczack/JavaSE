package Ataraxia.JavaSE.Genericity;
import java.util.*;
/*定义Employee类
1)该类包含:private成员变量name,sal,birthday,其中 birthday为 MyDate类的对象;
2)为每一个属性定义 getter, setter方法;
3)重写toString 方法输出name, sal, birthday.
4) MyDate类包含: private成员变量month,day,year;并为每一个属性定义 getter、setter方法;
5)创建该类的3个对象,并把这些对象放入ArrayList 集合中(ArrayList 需使用泛型来定义),对集合中的元素进行排序,并遍历输出
排序方式:调用ArrayList的sort方法，传入Comparator对象[使用泛型]，先按照name排序,如果name相同，则按生日日期的先后排序。
【即:定制排序】
 */

@java.lang.SuppressWarnings({"all"})
class Exercise{
    public static void main(String[] args) {
        ArrayList<Employee> employees = new ArrayList<>();
        employees.add(new Employee("jack", 1000, new MyDate(2002, 02, 2)));
        employees.add(new Employee("tom", 2000, new MyDate(2003, 11, 12)));
        employees.add(new Employee("smith", 14000, new MyDate(1997, 5, 22)));
        for(Employee employee : employees){
            System.out.println(employee);
        }
        employees.sort(new Comparator<Employee>(){
            //先判断是否是本类成员,再判断name,compareTo:若相同返回0  再依次判断年月日
            public int compare(Employee emp1,Employee emp2){
                if(!(emp1 instanceof Employee && emp2 instanceof Employee))
                    return 0;
                int i = emp1.getName().compareTo(emp2.getName());
                if(i!=0)
                    return i;
                return emp1.getBirthday().compareTo(emp2.getBirthday());//调用了重写后的方法
            }
        });
        System.out.println("==========");
        for(Employee employee : employees){
            System.out.println(employee);
        }
    }
}
class MyDate implements Comparable<MyDate>{//实现比较接口并实现其抽象类,将年月日得判断移至本类
    private int year;
    private int month;
    private int day;

    public MyDate(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
    @Override
    public int compareTo(MyDate o){//再做修改，year：this.year-传入的year
        int yearMinus = year - o.getYear();
        if(yearMinus!=0)
            return yearMinus;
        int monthMinus = month - o.getMonth();
        if(monthMinus!=0)
            return monthMinus;
        return day - o.getDay();
    }


    @Override
    public String toString() {
        return "MyDate{" +
                "year=" + year +
                ", month=" + month +
                ", day=" + day +
                '}';
    }
}
class Employee{
    private String name;
    private double salary;
    private MyDate birthday;

    public Employee(String name, double salary, MyDate birthday) {
        this.name = name;
        this.salary = salary;
        this.birthday = birthday;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public MyDate getBirthday() {
        return birthday;
    }

    public void setBirthday(MyDate birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", salary=" + salary +
                ", birthday=" + birthday +
                '}';
    }
}
