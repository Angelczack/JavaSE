package Ataraxia.JavaSE.Genericity;

import java.util.*;

public class AboutSet_Map {
    public static void main(String[] args) {
        Set<Student> set = new HashSet<Student>();//关于集合的泛型,都是实现了集合声明时的泛型
        set.add(new Student("john",12));//只能添加Student对象
        //使用iterator遍历
        Iterator<Student> iterator = set.iterator();
        while(iterator.hasNext()){
            Student student = iterator.next();//只能用泛型实现类接收
            System.out.println(student);
            System.out.println("======");
            HashMap_();
        }
    }
    static void HashMap_(){
        //HashMap也同样,实现了底层Map<K,V>
        Map<String,Student> map = new HashMap<String, Student>();
        map.put("jack",new Student("jack",11));
        //Map有entrySet集合，先获取
        Set<Map.Entry<String,Student>> set = map.entrySet();
        Iterator<Map.Entry<String,Student>> iterator = set.iterator();
        while(iterator.hasNext()){
            Map.Entry<String,Student> entry = iterator.next();
            System.out.println(entry);
        }
    }
}
class Student{
    public String name;
    public int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
