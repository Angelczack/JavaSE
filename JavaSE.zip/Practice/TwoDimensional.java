package Ataraxia.JavaSE.Practice;
/*
    1
    2 2
    3 3 3
 */
public class TwoDimensional {
    public static void main(String[] args){
        int i,j;
        int arr[][]=new int [3][];//create a two dimensional and only confirm it rows
        //the (new) interpret to give two dimensional to create a space
        for(i=0;i<arr.length;i++){
            arr[i]=new int[i+1];
            for(j=0;j<arr[i].length;j++){
                arr[i][j]=i+1;
            }
        }
        for(i=0;i<arr.length;i++) {
            for (j = 0; j < arr[i].length; j++)
                System.out.print(arr[i][j]);
                System.out.println();
        }
        System.out.println("————————————————");
        int account[][]={{2,3,2},{1,20,2},{-2}};
        int sum=0;
        for(i=0;i<account.length;i++)
            //the (account[i]) is different with upper,because this is determinate
            for(j=0;j<account[i].length;j++)
                sum+=account[i][j];
        System.out.print("The answer of addition is:"+sum);
    }
}
