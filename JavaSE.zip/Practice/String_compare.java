package Ataraxia.JavaSE.Practice;
import java.util.Scanner;
public class String_compare {
    public static void main(String[] args){
        String digit[]={"白眉鹰王","金毛狮王","紫衫龙王","青翼蝠王"};
        Scanner my = new Scanner(System.in);
        String s=my.next();
        int i,index=0;
        for(i=0;i<digit.length;i++) {
            if (s.equals(digit[i])) {
                System.out.println("恭喜找到" + s + "\n" + "number is\t" + i + 1);
                //此equals函数为 输入的字符(.)(是否)与后面（）内的字符串一样
                index = 1;
                break;
            }
        }
           if(index==0){
               System.out.println("fail to discover");
           }
    }
}
