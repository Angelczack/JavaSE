package Ataraxia.JavaSE.Practice;
import java.util.Scanner;

public class BooleanMethod {
    public static void main(String... args){
        Scanner whether = new Scanner(System.in);

        AA aa = new AA();
        if(aa.estimate(whether.nextInt()))
            System.out.println("The number is odd");
        else
            System.out.println("The number is not odd");
    }
}

class AA{
    boolean estimate(int num){//判断  奇偶
        /*if(num%2==1)return true;
        else return false;*/

        //return num%2==1 ? true : false;
        return num%2==1;
    }
}

