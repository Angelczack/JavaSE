package Ataraxia.JavaSE.Practice;
/*
        1
        1 1
        1 2 1
        1 3 3 1
        1 4 6 4 1
        1 5 10 10 5 1
        ···
!  We can find that every subsequent num all are upper two num to add
!  such as 1+1=2 ; 1+2=3; 2+1=3; 1+3=4; 3+3=6 ···
 */
public class YangHuiTriangle {
    public static void main(String[] args){//0,0 0,1 ;1,0 1,1 1,2;2,0 2,1 2,2
        int arr[][]=new int[6][];
        int i,j;
        for(i=0;i<arr.length;i++){
            arr[i]=new int[i+1];
            for(j=0;j<arr[i].length;j++){
                if(j==0||j==arr[i].length-1)
                    arr[i][j]=1;
                else{
                    arr[i][j]=arr[i-1][j]+arr[i-1][j-1];
                }
            }
        }
        for(i=0;i<arr.length;i++) {
            for (j = 0; j < arr[i].length; j++)
                System.out.print(arr[i][j]+"\t");
                System.out.println();
        }
    }

}
