package Ataraxia.JavaSE.Practice;

public class HomeWork_PolyArraySort {

    public static void main(String... args) {
        Person maxAge;//临时变量  与下面共同判断的类，不是父类
        Person[] people = new Person[3];
        people[0] = new Person("张三",50,"工程师");
        people[1] = new Person("李四",30,"老师");
        people[2] = new Person("王五",20,"机械师");
        for(int i=0;i<people.length;i++){
            System.out.println(people[i]);//toString方法被重写后，可以直接调用
        }
        for(int i=0;i<people.length-1;i++){
            for(int j=i;j<people.length-1;j++){//年龄从大到小
                if(people[i].getAge()<people[i+1].getAge()){//getAge获取
                    //冒泡排序法
                    maxAge = people[i];
                    people[i] = people[i+1];
                    people[i+1] = maxAge;
                }
            }
        }
        for(int i=0;i<people.length;i++)
            System.out.println(people[i].getAge());
    }
}
class Person{
    private String name;
    private int age;
    private String job;
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Person(String name,int age,String job){
        this.age = age;
        this.name = name;
        this.job = job;
    }
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", job='" + job + '\'' +
                '}';
    }
}
