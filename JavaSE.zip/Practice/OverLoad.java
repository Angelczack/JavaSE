package Ataraxia.JavaSE.Practice;

public class OverLoad {
    public static void main(String... args){
        int a=10,b=20,c=35;
        System.out.println(max(a,b));
        System.out.println(max(a,b));
        System.out.println(max(a,b,c));
    }
    static int max(int a,int b){
        if(a>b)return a;
        else return b;
    }
    static double max(double b,double c){
        return b>c?b:c;
    }
    static double max(double a, double b, double c){//the number is different and shape
        if(a>b){
            if(a>c)return a;
            else return c;
        }else if(b>a) {
            if (b > c) return b;
            else return c;
        }
        return c;
    }
}
