package Ataraxia.JavaSE.ExceptionHandle;

public class Throw {//自定义异常
    //自定义异常：创建一个类并继承Exception，通过throw抛给类对象.
    public static void main(String[] args) {
        /*throw与throws的区别：
            throw:1.自定义异常的关键字  2.位于方法声明处  3.后面跟的：异常类型
            throws:1.异常处理的一种方式 2.位于方法体之中  3.后面跟的：异常对象
         */
        int age = 19;
        if(!(age>=18 && age<=120)){
            throw new CaseException("年龄需在18~120之间");
        }
        System.out.println("你的年龄范围正确");
    }
}
//关于继承类型：编译时：exception;运行时：RuntimeException
class CaseException extends RuntimeException{
    public CaseException(String message){
        super(message);
    }
}