package Ataraxia.JavaSE.ExceptionHandle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Throws {
    public static void main(String[] args) {
        //对于编译异常，程序必须处理，比如try-catch或throws
        //对于运行时异常，若无处理，默认有throws
        //子类重写父类方法时，抛出异常的规定：子类的异常类型必须和父类一致，或者子类的异常类型必须是父类异常类型的子类
        //throws调用一个异常方法，若是编译类型错误，必须一致抛出;若运行时错误，可以直接调用因为有默认
    }
    public static void f1() throws FileNotFoundException{
        f2();//因为编译类型，所以调用者一致抛出
    }
    public static void f2() throws FileNotFoundException {
        FileInputStream file = new FileInputStream("d://aa.txt");
        //此为编译异常所以必须处理
    }

    public static void f4(){
        f5();//运行时异常，可以直接调用，因为有默认的异常抛出
    }
    public static void f5() throws RuntimeException{//运行时异常
    }
}
class Father{
    void run() throws java.lang.Exception {
    }
}
class Son extends Father{
    void run() throws RuntimeException{//继承重写，异常类型必须一致或为父类的子类型
    }
}
