package Ataraxia.JavaSE.ExceptionHandle;

public class Exception {//异常处理
    //exception与error:exception分为编译时和运行时，均可修改;error错误无法处理
    public static void main(String[] args) throws java.lang.Exception {
        int i=1;
        //无try{}catch系统默认throws,用try{ }catch(){}与throws解决
        //若没有异常，catch不会执行，只会执行try与finally;若有只执行catch中的语句
        //若有多个catch，只会匹配一个catch，并且()中父类对象在最后
        /*
        try{}finally{}语句:
        由于没有catch捕获命令，所以若是异常了try不会执行只会执行finally并且执行完，
        程序崩溃，finally{}后面的代码不会再执行
         */
        //注：无论try中是否有多个异常代码，遇到异常前会正常运行输出直到遇到一个异常终止后面所有
        try {
            System.out.println("try");
            i++;
            Person person = new Person();
            person = null;//指向空，报错：空指针异常
            System.out.println(person.getName());
            int n1 = 10;
            int n2 = 0;
            int res = n1 / n2;//分母不能为0，算数异常
            System.out.println(res);
        }catch(ArithmeticException e){
            System.out.println(e.getMessage());
            ++i;
        }catch(NullPointerException e){
            System.out.println(e.getMessage());
            ++i;
        }catch(java.lang.Exception e){//exception为异常父类，多个catch需在后面
            System.out.println(e.getMessage());
            ++i;
        }finally{
            System.out.println("finally");//不管异不异常，finally都会执行
            i++;
            System.out.println(i);
            //注重第一个异常，其他的不会增加，但会进入匹配的catch中去，若有return,不会返回；因为finally必定执行，只返回finally
        }
        System.out.println("继续执行");
    }
}
class Person{
    private String name = "wang";
    public String getName(){
        return name;
    }
}
