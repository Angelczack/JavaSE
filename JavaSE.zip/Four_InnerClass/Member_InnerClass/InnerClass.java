package Ataraxia.JavaSE.Four_InnerClass.Member_InnerClass;

public class InnerClass {
    public static void main(String[] args) {//成员内部类，大部分同局部内部类一样
        //不同于局部类的只有调用：因为在外部其他类中调用一个成员变量可以创建对象调用
        Outer outer = new Outer();
        System.out.println("外部其他类调用:"+outer.salary);
        //第一种方式：看成在外部类中创建内部类对象 new Inner();
        Outer.Inner IO = outer.new Inner();//右边的outer是外部类的实例引用
        IO.say();
        //第二种方法:创建一个在外部类中返回内部类新对象的方法
        Outer.Inner example = outer.getInstance();
        example.talk();
        //第三种：与第一种一样，直接创建外部类对象
        Outer.Inner in = new Outer().new Inner();
        in.combat();
    }
}
class Outer{
    private int money = 100;
    public double salary = 11.1;
    protected class Inner{//看成一个成员变量，可以加修饰符
        public void say(){
            System.out.println("第一种方式："+money);//直接访问
        }
        public void talk(){
            System.out.println("第二种方式");
        }
        void combat(){
            System.out.println("第三种方式");
        }
    }
    public Inner getInstance(){
        return new Inner();
    }
    void teach() {
        Inner inner = new Inner();//外部类访问需要创建对象
    }
}
