package Ataraxia.JavaSE.Four_InnerClass.Local_InnerClass;

//局部内部类：像局部变量一样，定义在方法、构造器、代码块当中;也因为局部，所以外部其他类无法直接访问到内部类
public class InnerClass {
    public static void main(String[] args) {
        Outer outer = new Outer();
        outer.method();//创建外部对象调用方法时，无法进入，会跳到底部的内部类创建进入；
    }
}
class Outer{//外部类
    private int parameter = 10;
    void c(){}
    public void method(){//外部类里的方法
        class Inner{//外部类
            //由于本质上就是一个局部变量，所以不能添加任何的修饰符，只能使用final修饰
            private int parameter = 50;
            public void method(){//在内部类中可以访问外部类中的所有成员，包括private类型
                //当外部类与内部类中的属性名重合时，默认遵循就近原则，访问外部类有语法：外部类名.this.属性
                System.out.println("内部类变量:"+parameter+"\t外部类属性:"+Outer.this.parameter);
                c();//并且可以直接访问
            }
        }
        //在外部类中访问内部类中的方法，需要创建其对象
        Inner inner = new Inner();
        inner.method();
    }
}
