package Ataraxia.JavaSE.Four_InnerClass.Static_InnerClass;

public class InnerClass {//静态内部类，是一个静态成员变量,所以与成员内部类近似
        //外部其他类访问内部类：也与成员类近似
        public static void main(String[] args) {
            //第一种：由于静态，所以可以先new再直接创建访问
            Outer.Inner inner = new Outer.Inner();
            inner.eat();
            //第二种：也是创建一个返回对象的方法,上面new在前面是先创建对象所以不需要再创Outer对象
            Outer outer = new Outer();
            Outer.Inner in = outer.getInstance();
            in.drink();
            //第三种：创建一个返回对象的(静态)方法,所以不需要对象引用，直接访问
            Outer.Inner IO = Outer.getInstance_();
            IO.set();
        }
}
class Outer{
    private static int n1 = 10;
    private static int score = 60;
    static class Inner{//与成员内部类一样，外部类中访问需要创建方法再创建内部类对象
        private int n1 = 20;
        public void eat(){//不一样的是，属性重名遵守就近原则，由于静态权限，访问外部时不需要添加this
            System.out.println("内部类n1:"+n1+"\t外部类n1:"+Outer.n1);
            //静态内部类只能访问静态成员;
            System.out.println("第一种方式"+score);

        }
        void drink(){
            System.out.println("第二种方式");
        }
        void set(){
            System.out.println("第三种方式");
        }
    }
        public Inner getInstance(){
            return new Inner();
    }
    public static Inner getInstance_(){
        return new Inner();
    }
}
