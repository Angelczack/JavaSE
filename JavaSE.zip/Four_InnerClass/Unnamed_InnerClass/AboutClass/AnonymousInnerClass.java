package Ataraxia.JavaSE.Four_InnerClass.Unnamed_InnerClass.AboutClass;

public class AnonymousInnerClass {//匿名内部类，基于类

    public static void main(String[] args) {
        //同基于接口类的匿名内部类一样
        /*这里有一个隐藏的类,类名：AnonymousInnerClass$1，如果是一起的，则按顺序分配数字
           class 类名 extends IC{
                void each(){}
           }
         */
        IC ic = new IC("参数"){
            public void each(){
                System.out.println("内部类的each方法");
            }
        };
        ic.each();
    }
}
class IC{
    public IC(String property){//构造器
        System.out.println(property);
    }
    public void each(){
        System.out.println("IC的each方法");
    }
}
