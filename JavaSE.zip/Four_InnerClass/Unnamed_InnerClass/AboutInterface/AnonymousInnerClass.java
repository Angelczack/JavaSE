package Ataraxia.JavaSE.Four_InnerClass.Unnamed_InnerClass.AboutInterface;

public class AnonymousInnerClass {//匿名内部类,基于接口

        //接口无法实例化对象，但是当运用内部类时可以实例化
        public static void main(String[] args) {
            IA inter = new IA(){
                //同多态：编译类型：IA  运行类型：匿名内部类
                /*这里有一个隐藏的匿名内部类，类名：外部类$1(只能使用一次)
                 语法：class 外部类名 implements IA{实现接口
                        public void inter(){
                            System.out.println("匿名内部类");
                        }
                    }
                 */
                public void inter(){
                    System.out.println("匿名内部类");
                }
            };
            inter.inter();//实例变量引用方法
            System.out.println("匿名内部类名："+inter.getClass());
        }

}
interface IA{
    void inter();
    /*匿名内部类的产生：调用接口需要创建一个类实现接口，然后创建类的对象
       有无数各类就有无数个对象，并且其类只使用一次就可以使用匿名内部类
       同局部内部类一样，创建在方法当中
    */
}
