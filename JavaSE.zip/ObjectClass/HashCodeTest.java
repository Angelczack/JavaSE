package Ataraxia.JavaSE.ObjectClass;

public class HashCodeTest {
    public static void main(String[] args) {
        Hash hash = new Hash(110);
        Hash hashd = new Hash(110);
        Hash hashde = hash;
        System.out.println(hash.hashCode());
        //不一样的引用，hashCode值一定不一样，一样的引用则相同。当然，哈希值是十进制的
        //hashcode是有地址号取得，却不同于地址
        System.out.println(hashd.hashCode());
        System.out.println(hashde.hashCode());
    }
}
class Hash{
    private int code;
    Hash(int code){
        this.code = code;
    }
}
