package Ataraxia.JavaSE.ObjectClass;

public class ToStringTest {
    //默认返回：全类名+@+哈希值的十六进制
    //全类名：包名+类名
    public static void main(String[] args) {
        Mouse mouse = new Mouse("雷蛇",300);
        System.out.println(mouse.toString());
        //当直接输出对象引用名时，默认toString值
        System.out.println(mouse);
    }

}
class Mouse{
    private String name;
    private int money;
    public Mouse(String name,int money){
        this.name = name;
        this.money = money;
    }
}
