package Ataraxia.JavaSE.ObjectClass;

public class EqualTest {
    public static void main(String[] args) {
        /*equals 与 ==的区别：
            ==可用于基本类型比较和对象引用类型比较，前者为值，后者为地址
           而 equals 只能用于比较对象类型引用，寻常的字符比较是由于
           其来自String方法构造的各个字符的比较：这里重写了父类Object的String方法
           Object顶级父类只有对象引用。

           添加:在基本数据类型下，==比较的是值;   在引用数据类型下,==比较的是地址值
         */
        Compare compare1 = new Compare("java",20);
        Compare compare2 = new Compare("java",20);
        System.out.println(compare1 == compare2);
        //都创建了不同的新对象，所以指向不是同一个
        //重写方法后，比较的则是构造器中的数值
        System.out.println(compare1.equals(compare2));
        System.out.println("=========练习题=========");
        Person p1 = new Person();
        p1.name = "java";
        Person p2 = new Person();
        p2.name = "java";
        System.out.println(p1==p2);//不同对象引用地址,false
        System.out.println(p1.name .equals( p2.name));
        //先是p1.name引用了String类型的equals进行了重写，挨个比较字符，true
        System.out.println(p1.equals(p2));//同1，false
        String s1 = new String("asdf");
        String s2 = new String("asdf");
        System.out.println(s1.equals(s2));
        //对象直接构造String类型重写equals方法,true
        System.out.println(s1==s2);//==不比equals，false
    }
}
class Compare{
    //这里重写object父类的equals方法，进行值的判断
    public boolean equals(Object object){
        //如果引用的都是共同的对象则直接返回true
        if(this == object){
            return true;
        }
        //如果都不是引用的本类或子类里的，那必定是false了
        if(object instanceof Compare){
            //如果是，则返回将年龄性别比较
            Compare compare = (Compare)object;
            return this.name.equals(compare.name)
                    &&this.age==compare.age;
        }
        return false;
    }
    private String name;
    private int age;
    public Compare(String name,int age){
        this.name = name;
        this.age = age;
    }
}
class Person{
    public String name;
}
