package Ataraxia.JavaSE.Annotation;

import java.util.ArrayList;
import java.util.List;
//作用域：抑制所有类中的所有警告信息
@java.lang.SuppressWarnings({"all"})
public class SuppressWarnings {
    //抑制黄色警告,在{""}中，可以写入想要抑制的警告信息,并且作用域范围在写的位置。譬如：main方法只在main中生效
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("jack");
        list.add("tom");
        list.add("mary");
        int i;
        System.out.println(list.get(1));
    }
}
