package Ataraxia.JavaSE.Annotation;
public class Deprecated {

    public static void main(String[] args) {
        De de = new De();
        System.out.println(De.n1);
    }
}
//过时注解:表示过时了，可以使用但不推荐
@java.lang.Deprecated
class De{
    @java.lang.Deprecated
    static int n1 = 10;
    static void talk(){
        System.out.println("说话");
    }
}
