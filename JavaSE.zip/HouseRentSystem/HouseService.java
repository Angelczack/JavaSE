package Ataraxia.JavaSE.HouseRentSystem;

public class HouseService {
    private static HousePassage[] houses;
    private static int id=1;
    private static int HouseNumber=1;//已有一条房屋信息，从1开始计算
    //数组储存每一个房屋的全部信息
    //本服务界面可以调用,并对数据方便增删改查
    public HouseService(int size){//构造器,当被调用时可以更改有多少个房屋信息
        houses = new HousePassage[size];//初始化
        houses[0] = new HousePassage(1,"cat","123","江都区",1200,"已出租");
        System.out.println("");
    }
    public boolean Add(HousePassage newHouse){
        //如果添加上限了，则返回false;
        if(HouseNumber == houses.length) {
            System.out.println("----------信息已上限-----------");
            return false;
        }
        //将新房信息存入数组
        houses[HouseNumber++] = newHouse;//房屋数量递增
        newHouse.setId(++id);//设置一个id，先递增
        return true;
    }
    public static HousePassage findHouse(int id){
        //用下标查找，若找到则单独显示
        for (int i = 0; i < HouseNumber; i++)
            if(id == houses[i].getId())
                return houses[i];

            return null;//若没有找到则置空
    }
    public boolean delHouse(int num){//选择删除的序号
         int index=-1;//判断是否能进循环，无法进入则不存在
        
        //先查找对应下标的id再删除，删除：将后一位覆盖前一位并在结尾加结束标识符
        for(int i=0;i<HouseNumber;i++){
            if(num == houses[i].getId()){
                //将 要删除的下标赋给一个常量，并单独判断
                index = i;
            }
        }
        
        if(index == -1) {
            System.out.println("该数不存在");
            return false;
        }//无法找寻
        //若是找到了，则删除对应房屋信息
        for (int i = index; i < HouseNumber-1; i++) {//从要删除的房屋开始
            houses[i] = houses[i+1];
        }
        houses[--HouseNumber] = null;//将最后一个置空,防止空指针异常
        //若是一次删除多个，-1只能运行一次,并且先减1
        return true;
    }
    public HousePassage[] list(){
        return houses;
    }
}
