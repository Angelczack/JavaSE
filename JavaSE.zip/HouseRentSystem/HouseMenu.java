package Ataraxia.JavaSE.HouseRentSystem;

import Ataraxia.JavaSE.Utility;

public class HouseMenu {
        private static char num;//输入的序号
        private static boolean loop = true;//判断循环
        private static HouseService house = new HouseService(2);
        private static HousePassage added;
        private static int k=2;
        public static void addHouse(){
            //利用工具类添加房子信息
            System.out.println("----------添加房屋-----------");
            System.out.print("姓名：");
            String name = Utility.readString(5);
            System.out.print("电话：");
            String tel = Utility.readString(10);
            System.out.print("地址：");
            String add = Utility.readString(5);
            System.out.print("租金：");
            int rent = Utility.readInt();
            System.out.print("状态：");
            String state = Utility.readString(3);

            added= new HousePassage(0,name,tel,add,rent,state);
            //创建对象，调用passage的构造器
            if(house.Add(added)){
                System.out.println("----------添加成功-----------");
                System.out.println("----------添加完成-----------");
            }
            else
                System.out.println("----------添加失败-----------");

                System.out.println();
        }
        public static void findHouse(){
            //利用id查找房屋所有信息
            System.out.println("----------查找房屋-----------");
            System.out.println("请输入你要查找的id:");
            int num = Utility.readInt();
            if(house.findHouse(num) != null)//若返回空说明没有找到或输入有误,无则输出对应内容
                System.out.println(house.findHouse(num));
            else System.out.println("----------无法查找到相关信息----------");
        }
        public static void DelHouse(){
            //删除表数据
            System.out.println("请选择待删除房屋编号(-1退出)");
            int num = Utility.readInt();
            if(num == -1){
                System.out.println("放弃删除并退出");
                return;
            }
            System.out.println("确认是否删除(Y/N):请小心选择：");
            char choice = Utility.readConfirmSelection();
            if(choice == 'Y'){//真的删除
                 if(house.delHouse(num))
                     System.out.println("----------成功删除-----------");
                 else System.out.println("----------删除失败-----------");

            }else{
                System.out.println("放弃删除并退出");
            }
        }
        public static void update(){
            //修改数据，先查找后修改所以可以引用查找方法

            System.out.println("----------请选择待修改房屋编号(-1退出):");
            int num = Utility.readInt();
            if(num == -1) return;
            HousePassage hp = HouseService.findHouse(num);
            if(hp == null){//若house为null则无法查询到信息
                System.out.println("----------修改房屋的信息不存在");
                return;
            }
            //更新信息
            System.out.println("姓名("+hp.getName()+"):");
            String name = Utility.readString(5,"");//这里是：
                                                //若是回车没有更改，则默认
            //若是更改了，则 判断并更改
            if(!"".equals(name)){//更改后的值与默认不一样，说明已更改
                hp.setName(name);
            }

            System.out.println("电话("+hp.getTel()+"):");
            String tel = Utility.readString(10,"");
            //若是更改了，则 判断并更改
            if("".equals(tel)){//更改后的值与默认不一样，说明已更改
                hp.setTel(tel);
            }

            System.out.println("地址("+hp.getAdd()+"):");
            String add = Utility.readString(5,"");
            //若是更改了，则 判断并更改
            if(!"".equals(add)){//更改后的值与默认不一样，说明已更改
                hp.setAdd(add);
            }

            System.out.println("租金("+hp.getRent()+"):");
            int rent = Utility.readInt(-1);
            //若是更改了，则 判断并更改
            if(rent!=-1){//更改后的值与默认不一样，说明已更改
                hp.setRent(rent);
            }

            System.out.println("状态("+hp.getState()+"):");
            String state = Utility.readString(3);
            //若是更改了，则 判断并更改
            if(!"".equals(state)){//更改后的值与默认不一样，说明已更改
                hp.setState(state);
                }
            System.out.println("修改成功");
        }
        public static void listHouse(){//创建方法用以接收Service类中的list

        System.out.println("----------房屋列表-----------");
        System.out.println("编号\t\t房主\t\t电话\t\t地址\t\t\t月租\t\t\t状态(未出租/已出租)\t\t");
        HousePassage[] houses = house.list();
        for (int i = 0; i < houses.length; i++) {
            if(houses[i] == null){//之后多余的显示为null则终止循环
                break;
            }
            System.out.println(houses[i]);
        }
        System.out.println("----------房屋列表完成-----------");
        System.out.println();
    }
    public static void exitHouse(){
            char whether = Utility.readConfirmSelection();
            if(whether == 'Y'){
                System.out.println("成功退出");
                loop = false;
            }
    }
    public static void Menu(){
        //房屋主菜单界面

        do{
            System.out.println("----------房屋出租系统-----------");
            System.out.println("\t\t1 新 增 房 源");
            System.out.println("\t\t2 查 找 房 屋");
            System.out.println("\t\t3 删 除 房 屋");
            System.out.println("\t\t4 修 改 房 屋 信 息");
            System.out.println("\t\t5 房 屋 列 表");
            System.out.println("\t\t6 退      出");
            System.out.println("---请输入列号:");
            num = Utility.readChar();
            switch (num){
                case '1' :
                    addHouse();break;
                case '2' :
                    findHouse();break;
                case '3' :
                    DelHouse();break;
                case '4' :
                    update();break;
                case '5' :
                    listHouse();break;//调用房屋列表信息
                case '6' :
                    exitHouse();
                    break;
            }
        }while(loop);
    }
}
