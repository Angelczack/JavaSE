package Ataraxia.JavaSE.HouseRentSystem;

public class MainHouse {
    public static void main(String[] args) {
        new HouseMenu().Menu();
    }
}
