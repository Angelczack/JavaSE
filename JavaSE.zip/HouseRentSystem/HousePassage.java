package Ataraxia.JavaSE.HouseRentSystem;

public class HousePassage {
        //每一个房屋的独立信息
        //每个房屋都有编号，房主，电话，地址，月租以及状态
        private int id;
        private String name;
        private String tel;
        private String add;
        private int rent;
        private String state;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public int getRent() {
        return rent;
    }

    public void setRent(int rent) {
        this.rent = rent;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public HousePassage(int id, String name, String tel, String add, int rent, String state) {
        this.id = id;
        this.name = name;
        this.tel = tel;
        this.add = add;
        this.rent = rent;
        this.state = state;
    }

    @Override//重写输出
    public String toString() {
        return  id +"\t\t"+
                name+"     "+
                tel+"     "+
                add +"       "+
                rent +"\t\t\t"+
               state;
    }
}
