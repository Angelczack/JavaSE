package Ataraxia.JavaSE.System;

import java.util.Arrays;

public class CommonMethod {
    public static void main(String[] args) {
        int arr[] = {1,2,3};
        int copy[] = new int[3];//[0,0,0]
        //1.arraycopy:(1):被拷贝数组名 (2):从被拷贝数组下标开始
        //  (3):新拷贝数组名 (4):新拷贝数组名下标开始 (5)拷贝数组元素个数
        System.arraycopy(arr,1,copy,0,arr.length-1);
        //注:  数组拷贝:Array.copyOf();底层调用的就是它
        System.out.println(Arrays.toString(copy));
        //2.exit :退出程序,0为正常退出
            System.exit(0);
        //3.currentTimeMillis 前面讲过
            System.currentTimeMillis();
    }
}
