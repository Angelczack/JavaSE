package Ataraxia.JavaSE.PackageCase.Package2;

public class Person {
    public static void main(String... args){
        System.out.println("My name is XiaWa");
    }
}
