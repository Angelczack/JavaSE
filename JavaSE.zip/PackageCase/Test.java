package Ataraxia.JavaSE.PackageCase;//package must locate at the most top
import Ataraxia.JavaSE.PackageCase.Package1.Person;
//import Ataraxia.PackageCase.Package2.Person;

public class Test {
    public static void main(String[] args){
        //a package dont allow to appear comparable class
        //and hence i defined two package and the same class
        //use Person class in the different package have two methods:

        //for one thing is entering (import packageName .className) at the top;
        //but the method only use a person class,for another:
        //create packageObject:packageName.className useName = new packageName.className();
        //for instance:
        Person YaDang = new Person();
        System.out.println(YaDang);

        Ataraxia.JavaSE.PackageCase.Package2.Person XiaWa= new Ataraxia.JavaSE.PackageCase.Package2.Person();
        System.out.println(XiaWa);
    }
}
