package Ataraxia.JavaSE.Internet.TCP.Exercise;

import Ataraxia.JavaSE.StreamUtility;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws Exception {
        //服务端
        ServerSocket server = new ServerSocket(8888);
        String picture = "E:\\idea-java\\Stream\\other(1).jpg";
        Socket socket = server.accept();//等待连接
        //读取客户端发来的图片
        BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
        //转为字节
        byte[] bytes = StreamUtility.streamToByteArray(bis);
        //将收到的图片写到对应文件中去
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(picture));
        bos.write(bytes);//边读边写 不需要循环
        //写入收到图片
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        bw.write("收到图片");
        //按字符写入,需要刷新
        bw.flush();
        socket.shutdownOutput();
        //关闭流
        server.close();
        bis.close();
        bos.close();
        socket.close();
        bw.close();
    }
}
