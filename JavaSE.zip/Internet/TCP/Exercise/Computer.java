package Ataraxia.JavaSE.Internet.TCP.Exercise;

import Ataraxia.JavaSE.StreamUtility;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class Computer {

    /*  1.编写一个服务端,和一个客户端
        2.服务器端在9999端口监听
        3.客户端连接到服务端,发送一张图片
        4.服务器端接收到客户端发送的图片，保存到src下,发送“收到图片”再退出
        5.客户端接收到服务端发送的“收到图片"，再退出
        6.该程序要求使用StreamUtility.java

     */
    public static void main(String[] args) throws Exception {
        //客户端
        Socket socket = new Socket(InetAddress.getLocalHost(), 8888);//连接
        String picture = "E:\\idea-java\\Stream\\1.jpg";
        //获取图片
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(picture));
        //将这个图片转为字节用以边读边写
        byte[] bytes = StreamUtility.streamToByteArray(bis);
        //将客户端流转成buffered流
        BufferedOutputStream bos = new BufferedOutputStream(socket.getOutputStream());
        bos.write(bytes);//边读边写
        //接收收到图片  这里用字节流读入，可以使用utility转成字符串
        InputStream inputStream = socket.getInputStream();
        String message = StreamUtility.streamToString(inputStream);
        System.out.println(message);
        //关闭所有流
        socket.shutdownOutput();
        inputStream.close();
        bos.close();
        socket.close();
        bis.close();
    }
}