package Ataraxia.JavaSE.Internet.TCP;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class TCPOutputStream {//客户端，写入信息
        public static void main(String[] args) throws IOException {
            //由于客户端连接 用以本机名和端口号
            Socket socket = new Socket(InetAddress.getLocalHost(),9999);
            //连接成功后  创建信息流输入信息
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write("hello,server".getBytes());//转成字节
    /*这里写入字符流,但是这里需要将字节流转为字符

            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
            bufferedWriter.write("hello 字符流");
            //插入一个换行符,代表写入的内容结束  所以写了这个可以不需要shutdownOutput()了 ,但是需要对方使用readLine()
            bufferedWriter.newLine();
            bufferedWriter.flush();//如果使用的字符流需要刷新,否则数据不会写入数据通道

     */
            //由于一个端向另一个端写入信息,另一个端还在接收中无法回消息,所以需要在写入信息后使用结束方法
            socket.shutdownOutput();
            outputStream.close();
            socket.close();//记得将所有关闭
        }
    }
