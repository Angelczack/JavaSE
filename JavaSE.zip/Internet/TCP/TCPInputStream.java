package Ataraxia.JavaSE.Internet.TCP;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPInputStream {
    /*1.编写一个服务器端,和一个客户端
    2.服务器端在9999端口监听
    3.客户端连接到服务器端，发送"hello, server"，然后退出
    4.服务器端接收到客户端发送的信息,输出,并退出
     */
    //彼此发送信息必须在两端都建立socket对象用以连接  记得运行时一起run
    public static void main(String[] args) throws IOException {//服务端  接收信息
        //创建ServerSocket以在9999端口监听  ServerSocket可返回多个Socket
        ServerSocket server = new ServerSocket(9999);//前提是此端口没有被占用
        Socket socket = server.accept();//等待连接,若无连接则下方不会执行
        System.out.println("测试-"+socket.getClass());
        //连接成功后向下执行 创建信息流接收信息
        InputStream inputStream = socket.getInputStream();
        byte bytes[] = new byte[1024];
        int readLine = 0;
        while((readLine = inputStream.read(bytes)) != -1){
            System.out.println(new String(bytes,0,readLine));
        }
        //关闭所有流
        inputStream.close();
        socket.close();
        server.close();
    }
}
/*  TCP协议:传输控制协议
    1.使用TCP协议前,须先建立TCP连接,形成传输数据通道
    2.传输前,采用"三次握手"方式,是可靠的
    3. TCP协议进行通信的两个应用进程:客户端服务端
    4.在连接中可进行大数据量的传输
    5.传输完毕,需释放已建立的连接，效率低

 */