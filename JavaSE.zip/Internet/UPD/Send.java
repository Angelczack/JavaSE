package Ataraxia.JavaSE.Internet.UPD;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Send {
    public static void main(String[] args) throws IOException {
        //发送端
        //建立端口  发送和接收端端口号可以不一样,因为接收端/发送端也可以发送/接收
        DatagramSocket socket = new DatagramSocket(9998);
        //将字符串转成字节数组   转成数据包只能接收字节
        byte bytes[] = "hello,明天吃火锅~".getBytes();
        //发送需要添加发送给的主机和端口
        DatagramPacket packet = new DatagramPacket(bytes,bytes.length,InetAddress.getLocalHost(),9999);
        socket.send(packet);//发送
        System.out.println("发送完成");
        //
        //建立新数组,接收新消息  不能建立在close后面,否则会异常
        byte receive[] = new byte[60];
        DatagramPacket packetMe = new DatagramPacket(receive, receive.length);
        System.out.println("等待接收中...");
        socket.receive(packetMe);

        //同理，将数据包拆开
        int length = packetMe.getLength();
        byte read[] = packetMe.getData();
        String s = new String(read,0,length);
        System.out.println(s);
        //
        socket.close();

    }
}
