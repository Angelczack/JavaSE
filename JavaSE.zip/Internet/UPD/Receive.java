package Ataraxia.JavaSE.Internet.UPD;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Receive {//接收端
    public static void main(String[] args) throws IOException {
        //建立端口
        DatagramSocket socket = new DatagramSocket(9999);
        //发送小数据建立字节数组
        byte bytes[] = new byte[1024];
        //将数据封装成数据包
        DatagramPacket packet = new DatagramPacket(bytes,bytes.length);
        System.out.println("接收端等待接收数据...");
        socket.receive(packet);//与TCP的等待连接一样,等待接收前会堵塞
        //
        //接收消息后 回送消息  由于机制问题,不需要再创建端口   不能建立在close后面,否则会异常
        byte message[] = "好的,明天见".getBytes();
        DatagramPacket packetMe = new DatagramPacket(message, message.length, InetAddress.getLocalHost(), 9998);
        socket.send(packetMe);
        //
        socket.close();//关闭流

        //接收后需要拆包打开数据
        int length = packet.getLength();
        byte data[] = packet.getData();
        String s = new String(data,0,length);
        System.out.println(s);
        System.out.println("发送成功");

    }
}
/*  UDP协议:用户数据协议
            1．将数据、源、目的封装成数据包(DatagramPacket),不需要建立连接
            2.每个数据报的大小限制在64K内，不适合传输大量数据
            3.因无需连接，故是不可靠的
            4、发送数据结束时无需释放资源(因为不是面向连接的)，速度快
            5.举例:厕所通知:发短信
         */