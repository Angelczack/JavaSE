package Ataraxia.JavaSE.Internet;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetAddress_ {//获取本机主机名或ip地址的常用方法

    public static void main(String[] args) throws UnknownHostException {
        //1.获取本机的InetAddress 对象  主机名/ip地址
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println("直接获取本机信息"+localHost);
        //2.根据指定主机名 获取InetAddress对象
        InetAddress host1 = InetAddress.getByName("LAPTOP-FK3EHLI8");
        System.out.println("根据主机名获取信息"+host1);
        //3.根据域名返回InetAddress对象,比如www.baidu.com对应
        InetAddress host2 = InetAddress.getByName("www.baidu.com");
        System.out.println("百度的域名:"+host2);
        //4.通过InetAddress对象，获取对应的地址
        String hostAddress = host2.getHostAddress();
        System.out.println("host2对应的ip:"+hostAddress);
        //5.通过InetAddress对象,获取对应主机名/域名
        String hostName = host2.getHostName();
        System.out.println("host2对应的域名："+hostName);
    }
}
