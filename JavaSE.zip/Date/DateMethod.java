package Ataraxia.JavaSE.Date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class DateMethod {
    public static void main(String[] args) throws ParseException {
        //1.获取当前系统时间
        Date date = new Date();
        Date d = new Date(987464);//录入毫秒时间转换
        System.out.println("系统时间:"+date);//英文格式
        System.out.println("毫秒转换后:"+d);
        //2.转换为中文格式
        SimpleDateFormat simple = new SimpleDateFormat("yyyy年MM月dd日 hh:mm:ss E");
        String time = simple.format(date);//字符串接收
        System.out.println("中文格式:"+time);
        //3.将字符串日期转换为对应的Date,字符串必须与转换()里的格式一致
        String st = "1996年11月12日 17:05:45 周一";
        Date parse = simple.parse(st);//这里编译异常,需主动抛出
        System.out.println("字符串转换："+parse);//默认英文

        //第二代日期,可单独输出年月日时分秒
        System.out.println("========");
        Calendar_.method();

        //第三代日期,整合了前二代
        System.out.println("==========");
        Calendar_.quarter();
    }
}
class Calendar_{
    static void method(){
        //Calendar类是抽象类,无法实例化
        Calendar date = Calendar.getInstance();
        System.out.println(date.get(Calendar.YEAR));
        System.out.println(date.get((Calendar.MONTH)+1));
        System.out.println(date.get(Calendar.DAY_OF_MONTH));
        System.out.println(date.get(Calendar.HOUR));//24进制:HOUR_OF_DAY
        System.out.println(date.get(Calendar.MINUTE));
        System.out.println(date.get(Calendar.SECOND));
    }
    static void quarter(){
        LocalDateTime dt = LocalDateTime.now();//第一代版获取当前时间
        System.out.println("第三代:"+dt);
        System.out.println("获取年:"+dt.getYear()+"-"+dt.getMonthValue());
        //直接获取年月日时分秒  Value获取数字格式
        LocalDate localDate = LocalDate.now();//可以单独获取年月日
        LocalTime localTime = LocalTime.now();//也可以单独获取时分秒
        //单独获取的只能调用其个有参数
        System.out.println("date的个有参数:"+localDate.getDayOfMonth());
        System.out.println("time的个有参数:"+localTime.getHour());
        //还保留了第一代的转换格式
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy年MM月dd日 hh:mm:ss E");
        String pattern = format.format(dt);
        System.out.println(pattern);
        //时间戳:类似于date  与date的转换
        Instant now = Instant.now();
        Date date = Date.from(now);//instant -> date
        Instant instant = date.toInstant();//date -> instant
        //加减方法:plus、minus;后面可以跟年月日时分秒
        LocalDateTime plus = dt.plusDays(1);//一天之后
        LocalDateTime minus = dt.minusDays(2);//两天之前
        System.out.println("明天:"+format.format(plus)+"\t前天:"+format.format(minus));
    }
}
