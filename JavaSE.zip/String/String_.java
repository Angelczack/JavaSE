package Ataraxia.JavaSE.String;

public class String_ {
    public static void main(String[] args) {
        String s1 = "java";
        String s2 = new String("java");
        //创建了两个对象:==既有判断值也有判断对象之分
        System.out.println(s1 == s2);
        //区别:上面是在栈中的对象引用直接指向常量池;下面则是指向堆中String对象里的value方法然后指向常量池
        String s3 = "hello";
        s3 = "java";
        //创建了两个对象
        System.out.println(s3);
        //String有final修饰，所以这里更改的不是值，而是重新创建了一个对象引用并且断掉了与hello对象的连接
        System.out.println("========");
        //String a = "he"+"she";等价于 String a = "heshe";系统优化直接指向常量池
        String a = "he";
        String b = "she";
        String c = a+b;
        //创建了三个对象
        System.out.println(c);
        String d = "heshe";
        System.out.println(c == d);
        //值都是一样的,但是c的对象引用与构造器相同,是指向了String里的方法再调用常量池中的"heshe"

        AboutStringMethod();

        length();
    }
    static void AboutStringMethod(){
        System.out.println("==========接下来是关于String常用的方法的案例:");
        //1.equalsIgnoreCase  忽略大小写判断内容是否相等
        String n1 = "java";
        String n2 = "JAVA";
        System.out.println(n1.equals(n2)+"\t"+n1.equalsIgnoreCase(n2));
        //2.indexOf  获取字符或字符串在其第一次出现的索引,从0开始，若无法找寻，则返回-1  lastIndexOf方法则获取最后一次出现的索引
        String n3 = "12@34578@9";
        int c1 = n3.indexOf('@');
        int c2 = n3.lastIndexOf('@');
        System.out.println(c1+"\t"+c2);
        System.out.println(n3.indexOf("34"));
        //3.subString  截取指定范围的字符串
        String n4 = "hello,您好";
        System.out.println(n4.substring(6));//从下标为6的字符开始往后:[6,+∞)
        System.out.println(n4.substring(3,5));//从下标为3的字符开始往后，到5但不包括:[3,5)
        //4.与character里的toUpperCase,toLowerCase同样
        //5.concat 连接字符
        String n5 = "hello";
        n5 = n5.concat(" my").concat(" world");
        System.out.println(n5);
        //6.replace 替换字符串中的字符:将左边的字符替换成右边的
        System.out.println(n4.replace("您好","get out"));

        //7.split  分割字符串中所有的指定字符 , 若有特殊字符时,需要两侧加入转义符\
        String poem = "锄禾日当午,汗滴禾下土,谁知盘中餐,粒粒皆辛苦";
        //poem = "@./@\\";
        //分割后是一个字符数组
        String []split = poem.split(",");//  \\\\
        for (int i = 0; i < split.length; i++) {
            System.out.println(split[i]);
        }
        //8.toCharArray()  将一个字符串转换为字符数组
        String s = "Happy Birthday";
        char c[] = s.toCharArray();
        for (int i = 0; i < c.length; i++) {
            System.out.print(c[i]+" ");
        }
        System.out.println("");
    }
    static void length(){
        //9.compareTo  不考虑长度,首个不相同的单个字符比较,不一的左边同样减去右边;若相同返回0
        //注:若长度不一并且全部相同则按长度相减
        //枚举类(enumeration)也有compareTo,本质相同,相减的是编号,而不是单个字符
        String t1 = "java";
        String t2 = "jack";
        String t3 = "jac";
        System.out.println(t1.compareTo(t2));//v-c 22-3
        System.out.println(t3.compareTo(t2)+"\t"+t2.compareTo(t3));
        System.out.println(t2.compareTo(t1));//c-v 3-22

        //10.format  同c语言格式一样
        String name = "张三";
        float score = 65;
        char gender = '男';
        String info = String.format("名字:%s\n性别:%c\n这次考了%.2f分",name,gender,score);
        System.out.println(info);
    }
}
