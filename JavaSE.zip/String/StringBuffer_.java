package Ataraxia.JavaSE.String;

public class StringBuffer_ {
    //StringBuffer与String的区别:StringBuffer可以对字符串内容进行增删改查,并且是可变长度
    //String保存的是字符串常量,里面无法更改值,每次更新实际是更改地址(final);而StringBuffer保存的是变量

    /*!!StringBuilder与StringBuffer的创建,增删等操作一样(同为可变序列);唯一区别就是:
        StringBuilder效率最高,但在多线程中不安全,因此用于单线程之中
        而String效率最低，但复用率高;如果对String做大量修改，则不用

     */
    public static void main(String[] args) {
        StringBuffer s = new StringBuffer(10);//无双引号标记且为整数的是长度
        s.append("1234");
        System.out.println("length:"+s.length()+"\tcapacity:"+s.capacity());//前者是字符串长度,后者是初始化的长度
        StringBuilder ss = new StringBuilder("c++");//StringBuilder的创建
        System.out.println(ss);
        System.out.println("==========");
        
        //String与StringBuffer的转换:String->StringBuffer(两种)
        String s1 = "java";//创建String的值
        StringBuffer stringBuffer = new StringBuffer(s1);
        new StringBuffer().append(s1);

        //StringBuffer->String(两种)
        StringBuffer s2 = new StringBuffer("java");//创建StringBuffer值
        String string = new String(s2);
        s2.toString();
        System.out.println(s2);//StringBuffer无法输出,所以这里有默认隐藏的toString转换
        //由此可知,若一个字符串无法更改可以将其转换为StringBuffer进行增删改查,再进行输出
        Method.CommonMethod();
    }
}
class Method{
    static void CommonMethod(){//StringBuffer常用方法:增删改查插长度
        //增:append
        StringBuffer s = new StringBuffer("Hello");
        System.out.println("增添前:"+s);//隐藏toString
        s.append(',').append("张三").append(100);
        System.out.println("增添后:"+s);
        //删:delete
        s.delete(8,11);//与subString相同: 删除[8,11)
        System.out.println("删除后:"+s);
        //改:replace
        s.replace(6,8,"李四");//与String里的replace不同,这里是将[6,8)范围里改成""中的值
        System.out.println("改正后:"+s);
        //查:indexOf
        int n = s.indexOf(",");//与String里的indexOf相同:找字符或字符串第一个遇到的返回其索引,若无则-1
        System.out.println("索引:"+n);
        //插:insert
        s.insert(6,"王五,");//将索引为6的位置插入一个字符或字符串,原先为6的字符向后移
        System.out.println("插入后:"+s);
        //长度:与String一样,length可以验证其长度
    }
}
