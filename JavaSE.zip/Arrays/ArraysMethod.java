package Ataraxia.JavaSE.Arrays;

import java.util.Arrays;
import java.util.Comparator;

public class ArraysMethod {
    public static void main(String[] args) {
        //1.平时一个数组需要循环打印,现可以调用Arrays中toString方法打印
        int arr[] = {1,-1,0,9,4};
        Integer functionArr[] = {20,10,5,60,34};
        System.out.println(Arrays.toString(arr));
        //2.sort:从小到大默认排序,从大到小可以自定义排序
        Arrays.sort(arr);
        System.out.println("默认排序:"+Arrays.toString(arr));
        //2(2).自定义排序,用sort实现接口的匿名内部类
        Arrays.sort(functionArr,new Comparator(){
                public int compare(Object o1,Object o2){
                    Integer i1 = (Integer)o1;
                    Integer i2 = (Integer)o2;
                    return i2-i1;//后-前排序:从大到小
                }
        });
        System.out.println("自定义排序:"+Arrays.toString(functionArr));
        //3.binarySearch:二分查找下标,与index原理类似
        //要求:必须是排序好的数组,再进行查找
        System.out.println("排序后1的下标:"+Arrays.binarySearch(arr,1));
        //4.copyOf:将arr.length个元素的arr数组拷贝到copy数组中
        int copy[] = Arrays.copyOf(arr,arr.length);
        System.out.println("拷贝后:"+Arrays.toString(copy));
        //5.fill:数组填充,将arr数组中所有数填充成10
        Arrays.fill(arr,10);
        System.out.println("填充后:"+Arrays.toString(arr));
        //6.equals:数组中与String不一样,但原理相同:比较数组中所有值
        System.out.println("填充后的arr与被拷贝后的copy比较:\n"+Arrays.equals(arr,copy));
    }
}
