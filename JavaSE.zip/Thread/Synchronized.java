package Ataraxia.JavaSE.Thread;

public class Synchronized {
    //线程同步机制:当有一个线程对内存进行操作时,其他线程都不可以在对这个内存地址进行操作
    // ,直到该线程完成操作;线程执行顺序是随机的
    public static void main(String[] args) {
        /*1.同步代码块:
          非静态同步方法的锁可以是this,也可以是其他对象(要求是同一对象),默认是this
          静态同步方法的锁为当前类本身.class  默认是类名.class
            Synchronized(对象){//得到对象的锁,才能操作同步代码
                   //需要被同步代码
            }
         2.Synchronized 可以放在方法声明中,则为同步方法
         */
        new Ticket().start();
        new Ticket().start();
        new Ticket().start();
    }
}
class Ticket extends Thread{
    private int ticketNums = 50;
    private boolean loop = true;
    public /*synchronized*/ void method(){
        synchronized (this) {//三个线程一起争夺自身对象这个锁,谁拿到了就执行
            if (ticketNums <= 0) {
                System.out.println("售票结束");
                loop = false;
                return;
            }
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("窗口" + Thread.currentThread().getName() + "售出了一张票"
                    + "剩余票数:" + (--ticketNums));
        }
    }
    public void run(){
        while(loop) {
            method();
        }
    }
}
