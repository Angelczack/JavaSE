package Ataraxia.JavaSE.Thread;
/*线程中断:interrupt,中断休眠的线程
  线程插队:join:调用其方法的线程会被先执行完毕,再执行其他线程
         yield:调用其方法的线程会被让出,先执行其他的线程.而且不一定成功执行
  线程守护:当main线程结束时,子线程还没结束,可以将其设置为守护线程,将会一同终止  thread.setDaemon(true);

   线程七大状态:1.创建状态(NEW) 2.可运行状态(Runnable):就绪状态(Ready)/运行状态(Running)  3.结束状态(Terminated)
   4.堵塞状态(Blocked)需要锁打开synchronized  5.等待状态(Waiting) join··· 6.超时等待状态(TimedWaiting) sleep···
 */
public class Thread_ {
    public static void main(String[] args) throws InterruptedException{
        /*1.继承Thread并重写run方法,实现多线程
          2.实现Runnable,由于java的单继承机制,所以可以通过接口
            并重写方法,其接口没有start方法,需要通过创建Thread对象转换
         */

        Cat cat = new Cat();
        Dog dog = new Dog();
        Thread thread = new Thread(dog);
        thread.start();
        cat.start();//调用start,其中的start0方法会实现多线程,交替运行(先main线程,后子线程Cat)
        //start会让其进入可运行状态,不是立马运行,所以即使start在前面,也会进行一次main然后执行子线程,再交替
        for (int i = 0; i < 10; i++) {
            System.out.println(Thread.currentThread().getName());
            Thread.sleep(1000);
        }
    }
}
class Cat extends Thread{
    int times = 0;
    public void run(){
        while(true){
            //输出当前线程名
            System.out.println("小猫喵喵叫"+Thread.currentThread().getName()+(++times));
            try {
                Thread.sleep(1000);//每隔1秒循环一次
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if(times == 20)
                break;
        }
    }
}
class Dog implements Runnable{
    public void run(){
        int times = 0;
        while(true){
            //输出当前线程名
            System.out.println("小狗汪汪叫"+Thread.currentThread().getName()+(++times));
            try {
                Thread.sleep(1000);//每隔1秒循环一次
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if(times == 20)
                break;
        }
    }
}
