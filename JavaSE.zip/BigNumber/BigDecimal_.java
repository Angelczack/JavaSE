package Ataraxia.JavaSE.BigNumber;

import java.math.BigDecimal;

public class BigDecimal_ {
    //运算方法一致,原理一致,当小数不够用时,追求更高精度,可以使用此类
    public static void main(String[] args) {
        BigDecimal big1 = new BigDecimal("1.1322456789785464534897");
        BigDecimal big2 = new BigDecimal("55");
        System.out.println(big1.add(big2));
        System.out.println(big1.subtract(big2));
        System.out.println(big1.multiply(big2));
        System.out.println(big1.divide(big2,BigDecimal.ROUND_CEILING));
        //当小数除被除数时,答案可能为无限小数并异常;所以可以使用ROUND_CEILING方法保留精度
    }
}
