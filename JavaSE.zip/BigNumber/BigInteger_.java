package Ataraxia.JavaSE.BigNumber;

import java.math.BigInteger;

public class BigInteger_ {//当整数位数很多时,可以使用此类型

    public static void main(String[] args) {
        BigInteger big1 = new BigInteger("123456789123456789123456789");
        //底层会将字符串转换为Integer类型
        BigInteger big2 = new BigInteger("12");
        //调用方法进行加、减、乘、除:add(),subtract()、multiply、divide();
        System.out.println(big1.add(big2));
        System.out.println(big1.subtract(big2));
        System.out.println(big1.multiply(big2));
        System.out.println(big1.divide(big2));
    }
}
