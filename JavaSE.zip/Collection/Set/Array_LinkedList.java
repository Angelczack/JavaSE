package Ataraxia.JavaSE.Collection.Set;

public class Array_LinkedList {//数组链表模拟
    public static void main(String[] args) {
        //HashSet底层是HashMap,HashMap底层是(数组+链表+红黑树)
        //其子类:LinkedHashSet底层是LinkedHashMap,(数组+双向链表),添加的元素同样不能重复,但取出是为有序的
        //创建一个初始化数组(10个单位)
        Node node[] = new Node[10];
        //创建一个节点
        Node jack = new Node("jack",null);
        //将节点放入数组中去
        node[2] = jack;
        System.out.println(node);
        //再次创建一个节点放入第一节点中去,形成链表
        Node smith = new Node("smith",null);
        jack.next = smith;
        System.out.println(node);
    }
}
class Node{
    public Object item;//存放数据
    public Node next;

    public Node(Object item, Node next) {
        this.item = item;
        this.next = next;
    }

}
