package Ataraxia.JavaSE.Collection.Set;

import java.util.Comparator;
import java.util.TreeSet;

public class TreeSet_ {
    public static void main(String[] args) {
        //TreeSet会自动排序,默认正序   ;    其底层是TreeMap:根据key进行排序,自定义排序与TreeSet一样
         TreeSet tree = new TreeSet();
         tree.add("abc");
         tree.add("bac");
         tree.add("cba");
        System.out.println(tree);
        TreeSet treeSet = new TreeSet(new Comparator(){//自定义排序(与Arrays中类似)
            public int compare(Object o1,Object o2){
                return ((String)o2).compareTo((String)o1);//o2在前逆序,o1在前正序
            }
        });
        treeSet.add("abc");
        treeSet.add("bac");
        treeSet.add("cba");
        System.out.println(treeSet);
    }
}
