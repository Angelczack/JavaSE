package Ataraxia.JavaSE.Collection.Set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
@SuppressWarnings({"all"})
public class SetMethod {//Set/List是Collection的子接口,所以常用方法大同小异
    public static void main(String[] args) {
        //在set添加方法中,不像List中的元素/对象可以重复;并且读取出来是无序的
        //无序:HashSet(HashMap) ; 有序:LinkedHashSet(LinkedHashMap)
        Set set = new HashSet();
        set.add("java");
        set.add("python");
        set.add("python");
        set.add("c++");
        set.add(null);
        set.add(new Dog("tom"));//因为创建了两个对象,只是名字一样,所以都可添加
        set.add(new Dog("tom"));
        Dog dog = new Dog("dog");
        //同一对象不可重复
        set.add(dog);
        set.add(dog);
        //
        //迭代器和for增强同样都可以遍历
        Iterator iterator = set.iterator();
        while (iterator.hasNext()) {
            Object next =  iterator.next();
            System.out.println(next);
        }
    }
}
class Dog{
    private String name;

    public Dog(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                '}';
    }
}
