package Ataraxia.JavaSE.Collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
@SuppressWarnings({"all"})
public class ToolClass {
    //Collections的工具类      第一大组:排序操作(均为static方法)
    public static void main(String[] args) {
        System.out.println("=========第一组===========");
        List list = new ArrayList();
        list.add("java");
        list.add("c++");
        list.add("python");
        //1.reverse(List):反转List中元素的顺序
        Collections.reverse(list);
        System.out.println("反转后:"+list);
        //2.shuffle(List):随机排序
        Collections.shuffle(list);
        System.out.println("随机排序:"+list);
        //3.sort(List)：自然排序升序  和  sort(List,Comparator)  用法都和Arrays中的一样
        Collections.sort(list,new Comparator(){
            public int compare(Object o1,Object o2){
                return ((String)o1).length() - ((String)o2).length();
                //长度比较  自定义排序
            }
        });
        System.out.println("自定义排序后:"+list);
        //4.swap(List,int i,int j):将指定的List集合中的i处元素和j处元素调换
        Collections.swap(list,0,2);
        System.out.println("将下标0和2对换后:"+list);
        System.out.println("=========第二组===========");
        find.method(list);
    }
}
class find{
    static void method(List list){
        //Collections工具类      第二大组:查找、替换
        //1.Object max(Collection):返回集合中的最大值
        System.out.println("最大值:"+Collections.max(list));
        //2.Object max(Collection,Comparator)  用法与上面类似
        Object max = Collections.max(list,new Comparator(){
            public int compare(Object o1,Object o2){
                return ((String)o1).length() - ((String)o1).length();
            }
        });
        System.out.println("长度的最大元素:"+max);
        //3.Object min(Collection) 和 Object min(Collection,Comparator) 同上

        //4.int frequency(Collection,Object):返回元素出现在集合的次数
        list.add("java");
        int frequency = Collections.frequency(list,"java");
        System.out.println("添加后java出现的次数:"+frequency);
        //5.void copy(List desc,List src):将集合src的元素拷贝到集合desc中去
        //建立一个空集合来拷贝进去
        List desc = new ArrayList();
        //其源码表示尺寸不能小于被拷贝集合的数量,所以循环赋初值
        for (int i = 0; i < list.size(); i++) {
            desc.add("");
        }
        Collections.copy(desc,list);
        System.out.println("拷贝后的新集合:"+desc);
        //6.replaceAll(List list,Object oldVal,Object newVal):将list集合中的所有旧值替换成新的
        Collections.replaceAll(desc,"java","php");
        System.out.println("所以java替换后:"+desc);
    }
}
