package Ataraxia.JavaSE.Collection.List;

import java.util.ArrayList;
import java.util.List;

public class ListMethod {
    public static void main(String[] args) {
        //除了扩容机制外,Vector用法与ArrayList类似,不过前者更安全,后者效率更高(同StringBuffer和StringBuilder的关系)
        List list1 = new ArrayList();
        list1.add("龙虾");
        list1.add("面包");
        System.out.println("插入前:"+list1);
        //1.add(int index,Object ele)  在index位置插入ele元素
        list1.add(1,"汉堡");
        System.out.println("插入后"+list1);
        //2.addAll()  同上
        List list2 = new ArrayList();
        list2.add("鲶鱼");
        list2.add("草鱼");
        list1.addAll(3,list2);
        System.out.println("集合插入后:"+list1);
        //3.get 获取指定index位置的元素
        System.out.println("下标2的元素为:"+list1.get(2));
        //4.indexOf 与 lastIndexOf  与String里的方法一致:获取第一个元素的下标与最后一个
        System.out.println("面包下标为:"+list1.indexOf("面包"));
        //5.remove 移除指定下标的元素  与Collection中的一致
        list1.remove(2);
        System.out.println("删除面包后:"+list1);
        //6.set 相当于替换  用法与上面的add一致
        list1.set(0,"肉夹馍");
        System.out.println("替换龙虾后:"+list1);
        //7.subList(int fromIndex,int toIndex) 左闭右开  同String中的subString一样
        System.out.println("[0,2):"+list1.subList(0,2));
    }
}
