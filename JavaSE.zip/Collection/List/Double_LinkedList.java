package Ataraxia.JavaSE.Collection.List;

import java.util.Iterator;
import java.util.LinkedList;

public class Double_LinkedList {
        public static void main(String[] args) {
            /*linkedList与ArrayList用法也同样差不多,其区别:
            底层结构:前者是双向链表，后者是可变数组;前者适合增删，后者适合改查(因为数组下标好定位)
             */
            //*****LinkedList演示
            LinkedList list = new LinkedList();
            list.add(1);
            list.add(2);
            list.add(3);
            list.remove();//默认删除第一位元素
            list.set(1,99);//修改
            Iterator it = list.iterator();
            while(it.hasNext()){
                Object obj = it.next();
                System.out.println(obj);
            }
            //*******
            System.out.println("=======双向链表模拟=========");
            //创建三个对象,按正逆顺序指向
            Node java = new Node("java");
            Node c = new Node("c");
            Node python = new Node("python");
            java.next = c;
            c.next = python;

            //逆指向
            python.pre = c;
            c.pre = java;
            //循环遍历,首先创建头节点,尾节点
            Node first = java;
            while(true){
                //头节点依次往后输出,如果为空执行完毕
                if(first == null)
                    break;
                System.out.println(first);
                first = first.next;
            }
            System.out.println("========");
            //从后往前遍历
            Node last = python;
            while(true){
                if(last == null)
                    break;
                System.out.println(last);
                last = last.pre;
            }
            //在c和python中插入一个c++节点
            Node c_ = new Node("c++");
            //先将c_的next和pre指向,c和python之间的线会断开,重新再指向
            c_.next = python;
            c_.pre = c;

            c.next = c_;
            python.pre = c_;
            System.out.println("=========");
            first = java;//重新指向
            while(true){
                //头节点依次往后输出,如果为空执行完毕
                if(first == null)
                    break;
                System.out.println(first);
                first = first.next;
            }
        }
    }
    class Node{
        public Object it;
        public Node next;
        public Node pre;
        public Node(Object it){
            this.it = it;
        }

        @Override
        public String toString() {
            return "Node{" +
                    "it=" + it +
                    '}';
        }
}
