package Ataraxia.JavaSE.Collection;

import java.util.ArrayList;
import java.util.Collection;

public class CommonMethod {//Collection为单列集合,以下子接口常用方法都一致
    public static void main(String[] args) {
        Collection list = new ArrayList();
        //1.add:添加单个元素(任何类型)
        list.add("三体");
        list.add(true);
        list.add(10);//每个都会有类似如此隐藏的:new Integer(10);装箱操作
        System.out.println("add:"+list);
        //2.remove:删除指定元素
        list.remove(10);
        System.out.println("remove:"+list);
        //3.contains:查找元素是否存在  返回Boolean类型的值
        System.out.println("单个是否存在:"+list.contains("三体"));
        //4.size:获取元素个数
        System.out.println("元素个数:"+list.size());
        //5.isEmpty:判断是否为空
        System.out.println("是否为空:"+list.isEmpty());
        //6.clear:清空
        list.clear();
        System.out.println("清空后:"+list);
        //7.addAll:添加多个元素  重新创建集合,再添加
        Collection list2 = new ArrayList();
        list2.add("红楼梦");
        list2.add("水浒");
        list.addAll(list2);
        System.out.println("添加多个元素后:"+list);
        //8.containsAll:查找多个元素是否存在
        System.out.println("多个元素是否存在:"+list.containsAll(list2));
        //9.removeAll:删除多个元素
        list2.removeAll(list);
        System.out.println("删除多个元素后:"+list2);
    }
}
