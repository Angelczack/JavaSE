package Ataraxia.JavaSE.Collection;
import java.lang.Object;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
public class Iterator_ {//迭代器:遍历集合中的元素
    public static void main(String[] args) {
        Collection col = new ArrayList();
        col.add(new Book("三国演义","罗贯中",10.1));
        col.add(new Book("水浒传","施耐庵",48.3));
        col.add(new Book("红楼梦","曹雪芹",20.5));
        System.out.println("遍历前:"+col.toString());
        System.out.println("===========");
        //获取迭代器
        Iterator iterator = col.iterator();
        //循环遍历:iterator中hasNext()判断下一个是否有值,有就下一个(next()),无则终止(自动)
        while(iterator.hasNext()) {
            Object next = iterator.next();
            System.out.println("遍历后:"+next);
        }
        System.out.println("==========");
        //增强for循环可以替代iterator:底层还是迭代器   增强for只适用于集合和数组
        for(Object obj : col){
            System.out.println("循环:"+obj);
        }

    }
}
class Book{
    private String Book_Name;
    private String editor;
    private double price;

    public Book(String book_Name, String editor, double price) {
        Book_Name = book_Name;
        this.editor = editor;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "Book_Name='" + Book_Name + '\'' +
                ", editor='" + editor + '\'' +
                ", price=" + price +
                '}';
    }
}